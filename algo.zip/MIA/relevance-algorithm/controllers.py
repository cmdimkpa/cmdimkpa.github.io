from server.utils.base import *
from flask import Response, send_file
import subprocess
import pathlib
from copy import deepcopy
from http import HTTPStatus
import requests
from os import listdir
from os.path import isfile
from moderation import moderation_test

_HERE_ = pathlib.Path().parent.resolve()
_BACKGROUND_JOBS_PATH_ = os.path.join(_HERE_, "background_jobs.py")
_V2_PATH_ = os.path.join(_HERE_, "v2/")
_V2_BATCH_PATH_ = os.path.join(_V2_PATH_, "v2_batch.py")


def fetch_api_key():
    return os.environ["API_KEY"]


def fetch_correct_header(with_bearer: bool = True):
    api_key = fetch_api_key()
    return f"Bearer {api_key}" if with_bearer else api_key


def dump_response_dict(response_dict):
    try:
        response_dict_dumped = json.dumps(response_dict)
    except:
        response_dict_dumped = str(response_dict)
    return response_dict_dumped


def responsify(status, message, data={}, data_override={}):
    code = int(status)
    response_dict = {"message": message, "code": code}
    if not data_override:
        response_dict["data"] = data
    else:
        response_dict.update(data_override)
    return Response(
        dump_response_dict(response_dict), status=code, mimetype="application/json"
    )


def save_webserver_bg_job_args(args: Any, is_array: bool = False):
    global webserver
    args_hash = get_hash(args)
    job_key = f"bg_job_{args_hash}"
    webserver.put_secret(secret_name=job_key, secret_value=args, as_pkg=is_array)
    return job_key


def launch_background_job(args: dict, tasks: List[str]) -> None:
    job_key = save_webserver_bg_job_args(args)
    tasks_comma_separated = ",".join(tasks)
    launch_command = (
        f"python3 {_BACKGROUND_JOBS_PATH_} -jk '{job_key}' -t '{tasks_comma_separated}'"
    )
    subprocess.Popen(launch_command, shell=True)


def build_task_config(
    task_type, username: str = "internal", country: str = "AR", preferences: list = []
):
    task_config = dict(
        username=username,
        country=country,
        preferences=preferences,
        request_count=set_requests_count(context=task_type, sync_to_web=False),
        task_type=task_type,
        post_context=(task_type == "post"),
    )
    return task_config


def local_training_on_vpn_handler(conf):

    global webserver

    try:

        conf = dict(
            env=str(conf.get("target_env", "integration")).upper(),
            local_training_run=True,
            preferences=list(ModelParameters._KEYWORD_MAPPING.value.keys()),
        )

        for task_type in ["user", "post"]:
            # set task type and invoke model training
            conf["_type"] = task_type
            conf["task_type"] = task_type
            conf["task_config"] = build_task_config(task_type=task_type)
            # parallelize each training job
            launch_background_job(args=conf, tasks=["force_model_retrain"])

    except Exception as err:
        # print training errors
        print(str(err))

    # post-training: cleanup temp files and remove webserver job files

    webserver.delete_remote_secret(secret_name="user_artifact_*")
    webserver.delete_remote_secret(secret_name="post_artifact_*")

    # TODO: fix issue with BigQuery table
    # weblog(mode="bq")  # write new data pipe logs to BigQuery

    temp_files = [
        os.path.join(_HERE_, f)
        for f in listdir(_HERE_)
        if isfile(os.path.join(_HERE_, f)) and f.endswith(".tmps")
    ]

    for _file in temp_files:
        try:
            os.remove(_file)
        except:
            pass


def build_cmd_args(args: dict) -> str:
    return " ".join([f"-{key} {value}" for key, value in args.items()])


def v2_task_handler(args: dict):
    task_args = build_cmd_args(args)
    task_cmd = f"python3 {_V2_BATCH_PATH_} {task_args}"
    wait_for_result = args.get("wr", False)
    result = None
    if wait_for_result:
        raw_result = subprocess.check_output(task_cmd, shell=True)
        # parse raw output
        result = eval(raw_result.split(b"\n")[-2])
    else:
        subprocess.Popen(task_cmd, shell=True)
    return result


def comma_separated_param_list(args, param):
    return [_ for _ in args.get(param, "").replace(" ", "").split(",") if _]


def test_fetch_docs_handler(args: dict):
    collection = args.get("collection", "content")
    size = int(args.get("size", 10))
    env = args.get("env", "stage")
    fields = comma_separated_param_list(args, "fields")
    ids = comma_separated_param_list(args, "ids")
    docs = db_operation(
        args=dict(env=env),
        context="test_fetch_docs",
        op_args=[collection, size, ids, fields],
    )
    return serialize_data_types(docs)


_HANDLE_TASK_ROUTER = {
    "force-train-model": force_model_retrain_handler,
    "local-train-model": local_training_on_vpn_handler,
    "mark-unmark-ambassadors": mark_unmark_ambassadors_handler,
    "moderation-test": moderation_test,
    "v2-task": v2_task_handler,
    "test-fetch-docs": test_fetch_docs_handler,
}


def handle_request(task, request):

    request_method = str(request.method).lower()

    payload = (
        dict(request.form)
        or request.get_json(
            force=True,
            silent=True,
        )
        if request_method == "post"
        else dict(request.args)
    )

    username = payload.get("username")
    preferences = keyword_preprocessor(payload.get("preferences"))
    _env = payload.get("env")
    country = payload.get("country")
    no_likes = bool(payload.get("no_likes"))

    if request_method == "post":
        payload["preferences"] = preferences
        payload["no_likes"] = no_likes

    task_config = dict(
        username=username,
        country=country,
        preferences=preferences,
    )

    if task == "fetch-creators":
        _TASK_TYPE = "user"
    if task == "fetch-posts":
        _TASK_TYPE = "post"
    if task in UTIL_TASKS:
        _TASK_TYPE = payload.get("task_type")

    # update request count
    current_request_count = set_requests_count(context=_TASK_TYPE, sync_to_web=False)

    task_config.update(
        dict(
            request_count=current_request_count,
            task_type=_TASK_TYPE,
            post_context=(_TASK_TYPE == "post"),
        )
    )

    model_data_args = {
        "_type": _TASK_TYPE,
        "task_config": task_config,
        **payload,
    }

    if task in _HANDLE_TASK_ROUTER:
        task_input = model_data_args if request_method == "post" else payload
        __data = _HANDLE_TASK_ROUTER[task](task_input)
        return responsify(HTTPStatus.OK, "Success", __data)

    elif task not in UTIL_TASKS:
        return responsify(
            HTTPStatus.BAD_REQUEST,
            "Bad request: check username/preferences/country are provided",
        )
    else:
        return responsify(
            HTTPStatus.NO_CONTENT,
            "Successful",
        )
