/*
    this pipe will run queries against MongoDB and send results
    back to the calling Python process
*/

const { MongoClient } = require('mongodb');
const { ObjectId } = require('bson');
const args = require('args-parser')(process.argv);
const fs = require('fs');
const _ = require('lodash');
const flatten = require('flat');
const moment = require('moment');

// process variables
let {
    connection_string: url,
    database_name: dbName,
    collection_name: collectionName,
    mode,
    query: queryFilePath,
    projection: projectionFilePath,
    filter: filterFilePath,
    patch: patchFilePath,
    object_id_fields: objectIdFieldsPath,
    date_fields: dateFieldsPath
} = args;

const ObjectID = (item) => new ObjectId(item);

const getDate = (date_str) => moment(date_str).toDate()

const dataFromPath = (path) => {
    let obj =  JSON.parse(fs.readFileSync(path));
    fs.unlinkSync(path);
    return obj;
}

const mapEntity = (obj, mappableFields, mapFn) => {

    let _obj = flatten(obj);

    const refactor = (field) => {
        let value = _obj[field];
        _obj[field] = mapFn(value);
        return _obj;
    }

    if (!_.isEmpty(mappableFields)){
        let flatObjKeys = _.keys(_obj);
        let fieldsToMap = _.filter(mappableFields, (field) => _.includes(flatObjKeys, field));
        for (let field of fieldsToMap){
            _obj = refactor(field);
        }
    }

    return flatten.unflatten(_obj);
}

const mapObjectId = (obj, mappableFields) => mapEntity(obj, mappableFields, ObjectID);
const mapDate = (obj, mappableFields) => mapEntity(obj, mappableFields, getDate);


let dataPaths = [
    queryFilePath, projectionFilePath,
    filterFilePath, patchFilePath,
    objectIdFieldsPath, dateFieldsPath
];

// read data
let [query, projection, filter, patch, objectIdFields, dateFields] = dataPaths.map((path) => dataFromPath(path))

// create client
const client = new MongoClient(url);

async function main() {

  // connect client
  await client.connect();
  let db = client.db(dbName);
  let collection = db.collection(collectionName);

  // execute query and communicate results
  let result;

  if (!_.isEmpty(objectIdFields) || !_.isEmpty(dateFields)){

      // modify query and filter to convert to ObjectId and Date

      if (_.includes(["find", 'find_one'], mode) && !_.isEmpty(query)){
          query = mapObjectId(query, objectIdFields);
          query = mapDate(query, dateFields);
      }
      if (_.includes(["update", "delete"], mode) && !_.isEmpty(filter)){
          filter = mapObjectId(filter, objectIdFields);
          filter = mapDate(filter, dateFields);
      }
      if (mode === "insert"  && !_.isEmpty(query)){
          query = query.map((obj) => {
              obj = mapObjectId(obj, objectIdFields);
              obj = mapDate(obj, dateFields);
              return obj;
          });
      }
  }

  if (mode === "find") result = await collection.find(query, projection).toArray();
  if (mode === "find_one") result = await collection.findOne(query, projection);
  if (mode === "insert") result = await collection.insertMany(query);
  if (mode === "update") result = await collection.updateMany(filter, patch);
  if (mode === "delete") result = await collection.deleteMany(filter);
  if (mode === "drop"){
      await collection.drop();
      result = `dropped collection: ${collectionName}`;
  }

  await client.close();

  // pass result as message to Python process
  let message = JSON.stringify(result);
  console.log(message);
}

// run pipe process
main();



