# this pipe will run queries against MongoDB using PyMongo

from typing import Any, Callable
from pymongo import MongoClient
from bson import ObjectId
import os
import sys
from datetime import datetime
import pendulum
import argparse
import json
from flatten_dict import flatten, unflatten

_VALID_OP_MODES = ["find", "find_one", "update", "delete", "insert", "drop"]
_NOMINAL_DATA_LIMIT = 10000


def _flatten(obj: dict) -> dict:
    """
    flatten a JSON object
    """
    return flatten(obj, reducer="dot", max_flatten_depth=10)


def _unflatten(flat_obj: dict) -> dict:
    """
    unflatten a dict object
    """
    return unflatten(flat_obj, splitter="dot")


def ObjectID(item: Any) -> ObjectId:
    """
    return the ObjectId representation of an input
    """
    return ObjectId(item)


def getDate(timestamp: str) -> datetime:
    """
    convert a timestamp string to Python Datetime object
    """
    return pendulum.parse(timestamp).replace(tzinfo=None)


def dataFromPath(path: str) -> Any:
    """
    read JSON data at filepath and remove file
    """
    with open(path, "r") as handle:
        obj = json.loads(handle.read())
    try:
        os.remove(path)
    except Exception as err:
        print(str(err))
    return obj


def mapEntity(obj: dict, mappableFields: list, mapFn: Callable) -> Any:
    """
    convert query object data into required data types
    """

    _obj = _flatten(obj)

    def refactor(field):
        value = _obj[field]
        if isinstance(value, list):
            _obj[field] = [mapFn(item) for item in value]
        else:
            _obj[field] = mapFn(value)
        return _obj

    if mappableFields:
        flatObjKeys = list(_obj.keys())
        fieldsToMap = [field for field in mappableFields if field in flatObjKeys]
        for field in fieldsToMap:
            _obj = refactor(field)

    return _unflatten(_obj)


def mapObjectId(obj, mappableFields):
    return mapEntity(obj, mappableFields, ObjectID)


def mapDate(obj, mappableFields):
    return mapEntity(obj, mappableFields, getDate)


def map_all(item: Any):
    item = mapObjectId(item, objectIdFields)
    item = mapDate(item, dateFields)
    return item


parser = argparse.ArgumentParser()

parser.add_argument(
    "--connection-string",
    "-cs",
    type=str,
    required=True,
    help="the database connection string",
)
parser.add_argument(
    "--database-name", "-db", type=str, required=True, help="the database to connect to"
)
parser.add_argument(
    "--collection-name", "-col", type=str, required=True, help="the collection to query"
)
parser.add_argument(
    "--mode",
    "-m",
    type=str,
    required=True,
    choices=_VALID_OP_MODES,
    help="the database query type",
)
parser.add_argument(
    "--query-filepath",
    "-query",
    type=str,
    required=True,
    help="the path to the query file",
)
parser.add_argument(
    "--projection-filepath",
    "-projection",
    type=str,
    required=True,
    help="the path to the projection file",
)
parser.add_argument(
    "--filter-filepath",
    "-filter",
    type=str,
    required=True,
    help="the path to the filter file",
)
parser.add_argument(
    "--patch-filepath",
    "-patch",
    type=str,
    required=True,
    help="the path to the patch file",
)
parser.add_argument(
    "--oids-filepath",
    "-oids",
    type=str,
    required=True,
    help="the path to the ObjectIds file",
)
parser.add_argument(
    "--date-filepath",
    "-dates",
    type=str,
    required=True,
    help="the path to the dates file",
)

parser.add_argument(
    "--limit",
    "-lim",
    type=int,
    default=_NOMINAL_DATA_LIMIT,
    help="the data limit",
)

if __name__ == "__main__":
    args = parser.parse_args()

    # connect to database
    client = MongoClient(args.connection_string)
    db = client[args.database_name]
    collection = db[args.collection_name]

    # source data
    dataPaths = [
        args.query_filepath,
        args.projection_filepath,
        args.filter_filepath,
        args.patch_filepath,
        args.oids_filepath,
        args.date_filepath,
    ]

    query, projection, _filter, patch, objectIdFields, dateFields = [
        dataFromPath(path) for path in dataPaths
    ]

    # execute query and communicate results

    result = None

    if objectIdFields or dateFields:

        # modify query and filter to convert to ObjectId and Date

        if args.mode in ["find", "find_one"] and query:
            query = map_all(query)

        if args.mode in ["update", "delete"] and _filter:
            _filter = map_all(_filter)

        if args.mode == "insert" and query:
            query = [map_all(item) for item in query]

    if args.mode == "find":
        result = list(
            collection.find(query, projection).sort("updatedAt", -1).limit(args.limit)
        )

    if args.mode == "find_one":
        result = collection.find_one(query, projection)

    if args.mode == "insert":
        result = collection.insert_many(query).inserted_ids

    if args.mode == "update":
        result = collection.update_many(_filter, patch)

    if args.mode == "delete":
        result = collection.delete_many(_filter)

    if args.mode == "drop":
        collection.drop()
        result = f"dropped collection: {args.collection_name}"

    # close client connection
    client.close()

    # pass result as message to Python process
    message = repr(result)
    print(message)

    sys.exit()
