from flask_restx import fields


def get_content_schema():
    return {
        "detail": fields.Integer(),
        "format": fields.Integer(),
        "mode": fields.String(),
        "style": fields.String(),
        "text": fields.String(),
        "type": fields.String(required=True),
        "version": fields.Integer(required=True),
    }


def get_abstract_schema():
    return {
        "contentId": fields.String(required=True),
        "authorId": fields.String(required=True),
        "feedType": fields.String(required=True),
        "title": fields.String(),
        "mediaLink": fields.String(),
        "text": fields.String(),
        "longContent": fields.Boolean(required=True),
    }


def get_body_schema():
    return {
        "children": fields.List(fields.String()),
        "direction": fields.String(),
        "format": fields.String(),
        "indent": fields.Integer(),
        "type": fields.String(),
        "version": fields.Integer(),
    }


def get_feed_schema():
    return {
        "contentId": fields.String(required=True),
        "createdAt": fields.DateTime(required=True),
        "feedType": fields.String(required=True),
        "thumbnail": fields.String(),
        "title": fields.String(),
    }


def get_post_schema():
    return {
        "postId": fields.String(),
        "__STATE__": fields.String(),
        "body": fields.Nested(get_body_schema(), required=True),
        "creatorId": fields.String(required=True),
        "keywords": fields.List(fields.String(), required=True),
        "nsfw": fields.Boolean(required=True),
        "slug": fields.String(required=True),
        "status": fields.String(required=True),
        "tags": fields.List(fields.String()),
        "categories": fields.List(fields.String()),
        "thumbnail": fields.String(),
        "title": fields.String(),
        "updaterId": fields.String(required=True),
        "userId": fields.String(required=True),
    }


def get_reduced_post_schema():
    return {
        "_id": fields.String(),
        "creatorId": fields.String(),
        "thumbnail": fields.String(),
        "userId": fields.String(),
        "abstract": fields.Nested(get_abstract_schema()),
        "createdAt": fields.DateTime(),
        "updatedAt": fields.DateTime(),
    }


def get_notification_settings_schema():
    return {
        "regular": fields.Boolean(),
        "push": fields.Boolean(),
    }


def get_language_schema():
    return {
        "language": fields.String(),
        "properties": fields.String(),
    }


def get_location_schema():
    return {
        "country": fields.String(),
        "state": fields.String(),
        "city": fields.String(),
        "latitude": fields.String(),
        "longitude": fields.String(),
    }


def get_apparel_settings_schema():
    return {
        "banner": fields.String(),
        "background": fields.String(),
        "avatar": fields.String(),
    }


def get_profile_schema():
    return {
        "_id": fields.String(required=True),
        "accountId": fields.String(required=True),
        "status": fields.String(),
        "username": fields.String(required=True),
        "name": fields.String(),
        "about": fields.String(),
        "link": fields.String(),
        "gender": fields.String(),
        "location": fields.Nested(get_location_schema()),
        "language": fields.Nested(get_language_schema()),
        "interests": fields.List(fields.String()),
        "nsfw": fields.Boolean(),
        "apparelSettings": fields.Nested(get_apparel_settings_schema()),
        "notificationSettings": fields.Nested(get_notification_settings_schema()),
        "blockedUsers": fields.List(fields.String()),
        "isAmbassador": fields.Boolean(),
        "isCreator": fields.Boolean(),
    }
