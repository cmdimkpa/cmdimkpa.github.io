# common functions accessed between utilities

from typing import List, Any, Tuple, Union, Callable
import os
import pathlib
import json
from random import random
from hashlib import sha256
from flatten_dict import flatten, unflatten

_HERE_ = pathlib.Path().parent.resolve()

OBJECT_ID_FIELDS = [
    "_id",
    "accountId",
    "profileId",
    "userId",
    "authorId",
    "contentId",
]

WEBSERVER_ADDRESS = "35.225.91.166:81"


def _flatten(obj: dict) -> dict:
    """
    flatten a Python dict
    """
    return flatten(obj, reducer="dot", max_flatten_depth=10)


def _unflatten(flat_obj: dict) -> dict:
    """
    unflatten a Python dict
    """
    return unflatten(flat_obj, splitter="dot")


def rand_num(size: int = 10) -> str:
    """generate a random [10] digit string"""
    return str(random()).split(".")[1][:size]


def zero_pad(i: Union[int, str]) -> str:
    """
    this function takes an integer input and returns a string of length 2
    (0 padding)
    """
    i = str(i)
    return i if len(i) == 2 else f"0{i}"


def serialize_datetime(*args) -> str:
    """
    given the typical datetime args, this function assembles an equivalent output
    as datetime `isoformat()` calls

    the microsecond part is made up as the information is not always available in input args
    """
    yyyy, mm, dd, h, m, s, *_ = args
    return f"{yyyy}-{zero_pad(mm)}-{zero_pad(dd)}T{zero_pad(h)}:{zero_pad(m)}:{zero_pad(s)}.{rand_num(size=6)}"


def serialize_data_types(item: Any) -> Any:
    """
    this is a low-level and efficient approach for mass conversion of ObjectId and datetime
    objects to strings in any dataset by generating the `repr` of the dataset and doing
    simultaneous replacement of these non-JSON-serializable objects with their JSON-serializable
    equivalents. The JSON-serializable form of the dataset is then created by doing an `eval`
    on the resulting string.

    On benchmarks, this is much faster than iterating through each object in the dataset,
    inspecting the data type and then performing the substitution.
    """
    _item = repr(item)
    _item = _item.replace("ObjectId", "str")
    _item = _item.replace("datetime.datetime", "datetime")
    _item = _item.replace("datetime", "serialize_datetime")
    return eval(_item)


def write_json_file(_data):
    rand = rand_num(size=20)
    rand_file = os.path.join(_HERE_, f"{rand}.json")
    with open(rand_file, "w") as handle:
        handle.write(json.dumps(_data))
    return rand_file


def get_hash(obj: Any):
    obj = str(obj).encode()
    hasher = sha256()
    hasher.update(obj)
    return hasher.hexdigest()
