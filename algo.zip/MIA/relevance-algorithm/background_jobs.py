from controllers import train_model_data, force_model_retrain_handler, webserver
import argparse
import os
import json
import sys

parser = argparse.ArgumentParser()

parser.add_argument(
    "--job-key",
    "-jk",
    required=True,
    type=str,
    help="The job key for the subprocess",
)
parser.add_argument(
    "--tasks",
    "-t",
    required=True,
    type=str,
    help="A comma-separated list of tasks to run",
)


def train_model_data_handler(conf):
    train_model_data(**conf)


if __name__ == "__main__":
    args = parser.parse_args()
    job_key = args.job_key

    program_args = webserver.retrieve_secret(
        secret_name=job_key, decode=True, load_json=True
    )

    if program_args:

        program_args["job_key"] = job_key

        tasks = args.tasks.replace(" ", "").split(",")

        if "train_model_data" in tasks:
            train_model_data_handler(program_args)

        if "force_model_retrain" in tasks:
            force_model_retrain_handler(program_args)

    sys.exit()
