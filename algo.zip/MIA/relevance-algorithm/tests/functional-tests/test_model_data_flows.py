import pytest

import sys
import os
import pathlib

_ROOT_ = pathlib.Path().parent.resolve()
_BASE_DIR_ = os.path.join(_ROOT_, "server/utils/")
_FIXTURES_DIR_ = os.path.join(_ROOT_, "tests/fixtures/")

sys.path.extend([_BASE_DIR_, _FIXTURES_DIR_])

from base import (
    create_initial_buckets,
    SecretFileManager,
    ModelParameters,
    read_telemetry_artifact,
    push_signal,
    get_today,
)

from test_conf import (
    MODEL_TRAINING_TEST_ARGS,
    TEST_USERNAME,
    TEST_COUNTRY,
    TEST_PREFERENCES,
    MODEL_TRAINING_TEST_ARGS,
    TELEMETRY_TEST_DATA,
)

MODEL_TRAINING_TEST_ARGS["secrets"] = SecretFileManager()


@push_signal(telemetry_type="telemetry_test", signal_name="test_data")
def sample_telemetry_push(username, country, preferences):
    return dict(username=username, country=country, preferences=preferences)


def test_create_initial_buckets():

    user_inputs, post_inputs = create_initial_buckets(
        props=(TEST_PREFERENCES, TEST_COUNTRY), **MODEL_TRAINING_TEST_ARGS
    )

    assert user_inputs
    assert post_inputs
    assert isinstance(user_inputs, list) and len(user_inputs) > 0
    assert isinstance(post_inputs, list) and len(post_inputs) > 0

    sample_user = user_inputs[0]
    sample_post = post_inputs[0]

    assert isinstance(sample_user, dict)
    assert isinstance(sample_post, dict)

    sample_user_interests = sample_user["interests"]

    assert sample_user_interests

    sample_user_matched_test_preference = set(TEST_PREFERENCES).intersection(
        set(sample_user_interests)
    )

    assert sample_user_matched_test_preference


def test_telemetry_push():
    func_data = sample_telemetry_push(
        TEST_USERNAME, TEST_COUNTRY, preferences=TEST_PREFERENCES
    )
    (telemetry_data,) = read_telemetry_artifact(
        contexts=["test_data"],
        item_class="telemetry_test",
        experiment_date=get_today(),
    )
    assert func_data == TELEMETRY_TEST_DATA
    assert telemetry_data == TELEMETRY_TEST_DATA
