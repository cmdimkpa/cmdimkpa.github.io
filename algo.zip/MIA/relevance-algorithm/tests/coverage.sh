pytest -vv --cov=. tests/
