import pytest

import sys
import os
import pathlib

_ROOT_ = pathlib.Path().parent.resolve()
_BASE_DIR_ = os.path.join(_ROOT_, "server/utils/")
_FIXTURES_DIR_ = os.path.join(_ROOT_, "tests/fixtures/")

sys.path.extend([_BASE_DIR_, _FIXTURES_DIR_])

from base import webserver
from test_conf import WEBSERVER_BASE_URL, WEBSERVER_TEST_SECRET_NAME, WEBSERVER_TEST_SECRET_VALUE, apply_test_token

webserver = apply_test_token(webserver)

def test_webserver_initialization():
    assert webserver
    assert webserver.secrets_url_format.startswith(WEBSERVER_BASE_URL)

def test_webserver_save_retrieve_data():
    webserver.put_secret(secret_name=WEBSERVER_TEST_SECRET_NAME, secret_value=WEBSERVER_TEST_SECRET_VALUE)
    retrieved = webserver.retrieve_secret(secret_name=WEBSERVER_TEST_SECRET_NAME, use_cache=True, decode=True, load_json=True)
    assert retrieved == WEBSERVER_TEST_SECRET_VALUE

def test_webserver_caching():
    assert webserver.temp_files[WEBSERVER_TEST_SECRET_NAME] == WEBSERVER_TEST_SECRET_VALUE
