from typing import List
from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd

from v2_redis import CacheInterface
from v2_shared import get_hash
from v2_io import fetch_posts_content
from v2_conf import _RECOMMENDED_POST_THRESHOLD

import nltk
from nltk.corpus import stopwords
from string import punctuation

extra_punctuation = ("“", "”", "\n")

global cache

cache = CacheInterface()
cache.connect()

_CORPUS_SIZE_KEY = "V2_SYS_CORPUS_SIZE"


def get_env_based_key(env: str, key: str) -> str:
    return "{}.{}".format(env, key)


def read_corpus_size(env: str) -> tuple:
    use_key = get_env_based_key(env=env, key=_CORPUS_SIZE_KEY)
    return int(cache.client.get(use_key) or 0), use_key


def update_corpus_size(env: str, n_add: int = 1) -> None:
    corpus_size, use_key = read_corpus_size(env=env)
    cache.client.set(use_key, corpus_size + n_add)


def sort_and_hash(word_set: set) -> tuple:
    para = " ".join(sorted(word_set))
    return para, get_hash(para)


def clean_and_tokenize(text_input: str) -> set:
    """
    this function will clean and tokenize text input e.g. posts and comments
    """

    _stopwords = {
        *stopwords.words("english"),
        *stopwords.words("spanish"),
        *stopwords.words("portuguese"),
    }

    # 1. make lowercase
    text_input = str(text_input).lower()
    # 2. replace punctuation with space
    for char in {*punctuation, *extra_punctuation}:
        text_input = text_input.replace(char, " ")
    # 3. replace numbers with space
    for _ in range(10):
        text_input = text_input.replace(str(_), " ")
    # 4. tokenize words
    words = [_ for _ in text_input.split(" ") if _]
    # 5. filter stopwords
    words = {word for word in words if word not in _stopwords}

    return words


def fetch_env_corpus(env: str) -> List[tuple]:
    retrieve_profile = dict(
        dim_id=get_env_based_key(env=env, key="V2_SYS_CORPUS"),
        query_id=env,
        page_size=read_corpus_size(env=env)[0],
        current_page=1,
    )
    env_corpus, _ = cache.retrieve(**retrieve_profile)
    return env_corpus


def train_semantic_index(env: str, post_ids: List[str] = []) -> tuple:
    """
    this function updates the semantic index given some post ids
    """
    # 1. read the corpus (by env)
    env_corpus = fetch_env_corpus(env=env)
    env_hashes = []
    df_dict = {}

    for post_id, para, para_hash in env_corpus:
        df_dict[post_id] = [para]
        env_hashes.append(para_hash)

    # 2. update corpus with post data
    post_data = fetch_posts_content(post_ids=post_ids, env=env)
    candidates = []

    for post_id, post_text, _ in post_data:

        post_word_set = clean_and_tokenize(text_input=post_text)
        post_para, post_para_hash = sort_and_hash(word_set=post_word_set)

        if post_para_hash not in env_hashes:
            candidates.append((post_id, post_para, post_para_hash))
            df_dict[post_id] = [post_para]

    # 3. extend and save corpus
    if candidates:
        env_corpus.extend(candidates)
        update_corpus_size(env=env, n_add=len(candidates))
        insert_profile = dict(
            dim_id=get_env_based_key(env=env, key="V2_SYS_CORPUS"),
            dim_data=env_corpus,
            metadata=[len(env_corpus), env],
        )
        cache.insert(**insert_profile)

    # 4. dataframe vector operations
    input_df = pd.DataFrame(df_dict)
    vectorizer = TfidfVectorizer()
    word_vector = vectorizer.fit_transform(input_df.iloc[0])

    output_df = pd.DataFrame(
        word_vector.toarray().transpose(), index=vectorizer.get_feature_names_out()
    )
    output_df.columns = input_df.columns

    # 5. convert output dataframe to dict and store
    updated_index = output_df.to_dict(orient="split")
    insert_profile = dict(
        dim_id=get_env_based_key(env=env, key="V2_SYS_SEMANTIC_INDEX"),
        dim_data=updated_index,
        metadata=[1, env],
    )
    cache.insert(**insert_profile)

    return updated_index, post_data


def update_index_matches(word_set: set, index: dict, matches: dict = {}) -> dict:
    _index = index["index"]
    _data = index["data"]
    _columns = index["columns"]
    for word in word_set:
        if word in _index:
            word_index_pos = _index.index(word)
            post_word_scores = _data[word_index_pos]
            _pos = -1
            for score in post_word_scores:
                _pos += 1
                if score > 0.00:
                    post_id = _columns[_pos]
                    if post_id in matches:
                        matches[post_id]["count"] += 1
                        matches[post_id]["cumm_score"] += score
                    else:
                        matches[post_id] = {"count": 1, "cumm_score": score}
    return matches


def get_post_recency_score_by_index(
    post_recency_scores: List[float],
    post_ids: List[str],
    post_id: str,
    default_recency_score: float = 1.00,
) -> float:
    try:
        return post_recency_scores[post_ids.index(post_id)]
    except ValueError:
        return default_recency_score


def find_top_matches(
    retained_post_ids: List[str],
    exclude_post_ids: List[str],
    post_contents: List[str],
    post_recency_scores: List[float],
    semantic_index: dict,
    match_limit: int,
) -> List[str]:

    post_word_sets = [
        clean_and_tokenize(post_content) for post_content in post_contents
    ]
    match_document = {}

    for word_set in post_word_sets:
        match_document = update_index_matches(
            word_set=word_set, index=semantic_index, matches=match_document
        )

    post_scores = [
        {
            "post_id": post_id,
            "score": agg["count"]
            * agg["cumm_score"]
            * get_post_recency_score_by_index(
                post_recency_scores=post_recency_scores,
                post_ids=retained_post_ids,
                post_id=post_id,
            ),
        }
        for post_id, agg in match_document.items()
        if post_id not in exclude_post_ids
    ]

    post_scores_sorted = sorted(post_scores, key=lambda k: k["score"], reverse=True)

    recommended_posts = [item["post_id"] for item in post_scores_sorted[:match_limit]]

    return recommended_posts


def fetch_env_index(env: str) -> dict:
    retrieve_profile = dict(
        dim_id=get_env_based_key(env=env, key="V2_SYS_SEMANTIC_INDEX"),
        query_id=env,
        page_size=1,
        current_page=1,
    )
    (env_index,), _ = cache.retrieve(**retrieve_profile)
    return env_index


def recommend_posts_handler(
    env: str,
    post_ids: List[str],
    match_limit: int = _RECOMMENDED_POST_THRESHOLD,
    train_index: bool = False,
    exclude_post_ids=None,
) -> List[str]:

    if train_index:
        # train and retrieve index and post data
        env_index, post_data = train_semantic_index(env=env, post_ids=post_ids)
    else:
        # fetch post data
        post_data = fetch_posts_content(post_ids=post_ids, env=env)
        # fetch the index
        env_index = fetch_env_index(env=env)

    # collect post features
    retained_post_ids = []
    post_contents = []
    post_recency_scores = []
    for post_id, post_text, post_recency_score in post_data:
        retained_post_ids.append(post_id)
        post_contents.append(post_text)
        post_recency_scores.append(post_recency_score)

    # fetch recommendations
    recommended_posts = find_top_matches(
        retained_post_ids=retained_post_ids,
        exclude_post_ids=exclude_post_ids or list(),
        post_contents=post_contents,
        post_recency_scores=post_recency_scores,
        semantic_index=env_index,
        match_limit=match_limit,
    )

    return recommended_posts
