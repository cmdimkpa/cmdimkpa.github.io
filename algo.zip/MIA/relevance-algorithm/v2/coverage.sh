pytest -vv --disable-warnings --cov=. tests/unittests.py
