from typing import Any, Union, List
import os
import json
import requests as http
import pickle
from enum import Enum
import datetime
import subprocess
from retry import retry
from http import HTTPStatus
from bson import ObjectId

from v2_conf import (
    _WEBSERVER_HOST_ADDRESS,
    _TEST_API_KEY,
    _MONGO_DB_MAP,
    ARGS_SCHEMAS,
    ARGS_BUILDERS,
    PIPE_TEMPLATES,
    SYNCHRONOUS_PIPE_OPERATIONS,
    MAX_PIPE_OPERATION_RETRIES,
    PIPE_OPERATION_RETRY_DELAY_SECONDS,
)
from v2_shared import _HERE_, rand_num, clean_temp_files, now

true = True
false = False
null = undefined = None


class SecretFileManager:
    def __init__(self, force_secure: bool = False) -> None:
        self.force_secure = force_secure
        self.http_protocol = "http" if not self.force_secure else "https"
        self.secrets_url_format = (
            f"{self.http_protocol}://{_WEBSERVER_HOST_ADDRESS}/files/%s?token=%s"
        )
        self.secrets_token = os.environ.get("API_KEY", _TEST_API_KEY)
        self.temp_files = {}

    def live_retrieve(
        self,
        secret_name: str,
        decode=False,
        as_pkg: bool = False,
        load_json: bool = False,
        use_cache: bool = False,
    ):
        retrieve_url = self.secrets_url_format % (secret_name, self.secrets_token)
        try:
            _data = http.get(retrieve_url).content
        except Exception as err:
            print(err)
            _data = b""
        result = _data if not decode else _data.decode()
        if load_json and result:
            result = json.loads(result)
        if as_pkg and _data:
            pkg = re_eval(_data)
            result = [unpack_webserver_item(item) for item in pkg]
        if use_cache:
            self.temp_files[secret_name] = result
        return result

    def retrieve_secret(
        self,
        secret_name: str,
        decode=False,
        as_pkg: bool = False,
        load_json: bool = False,
        use_cache: bool = False,
    ) -> bytes:
        secret_name = secret_name if not as_pkg else f"{secret_name}.json"
        if use_cache and not check_stale_web_content(secret_name):
            result = self.temp_files.get(secret_name)
            if not result:
                result = self.live_retrieve(
                    secret_name,
                    decode=decode,
                    as_pkg=as_pkg,
                    load_json=load_json,
                    use_cache=use_cache,
                )
        else:
            result = self.live_retrieve(
                secret_name,
                decode=decode,
                as_pkg=as_pkg,
                load_json=load_json,
                use_cache=use_cache,
            )
        return result

    def put_secret(
        self, secret_name: str, secret_value: Any, as_pkg: bool = False
    ) -> None:
        secret_name = secret_name if not as_pkg else f"{secret_name}.json"
        put_url = self.secrets_url_format % (secret_name, self.secrets_token)
        if as_pkg:
            secret_value = ensure_list(secret_value)
            _data = [serialize(item).decode("ISO-8859-1") for item in secret_value]
        else:
            _data = secret_value
        try:
            http.put(
                url=put_url,
                data=json.dumps({"data": _data}),
                headers={"Content-Type": "application/json"},
            )
        except Exception as err:
            print(err)

    def write_temp_secret(self, secret_name: str) -> str:
        secret = self.retrieve_secret(secret_name)
        secret_path = write_temp_file(secret)
        if secret:
            self.temp_files[secret_name] = secret_path
        return secret_path

    def delete_secret(self, secret_name: str) -> None:
        target = self.temp_files.get(secret_name)
        try:
            os.remove(target)
        except:
            pass

    def delete_remote_secret(self, secret_name: str) -> int:
        delete_url = self.secrets_url_format % (secret_name, self.secrets_token)
        try:
            return http.delete(delete_url).status_code
        except Exception as err:
            print(err)
            return HTTPStatus.INTERNAL_SERVER_ERROR


webserver = SecretFileManager()


def elapsed_secs(t):
    """get the number of seconds elapsed since time t"""
    return (now() - t).total_seconds()


def get_secret_name_from_item_class(item_class, **kwargs):
    env = kwargs.get("env", kwargs.get("environment", "")).lower()
    if env in ["prod", "stage", "local"]:
        secret_name = f"{env}.{item_class}"
    else:
        secret_name = item_class
    return secret_name


class ItemWrapper:
    def __init__(self, item):
        self.id = rand_num()
        self.item = item


def read_item_from_webserver(item_class: str, **kwargs):
    global webserver
    # pull from webserver
    secret_name = get_secret_name_from_item_class(item_class, **kwargs)
    items = re_eval(webserver.retrieve_secret(secret_name=secret_name, as_pkg=True))
    result = None
    if items:
        _items = ItemWrapper(items)
        result = [_items]
    return result


def load_single_from_cache(item_class: str, load_from_web: bool = True, **kwargs):
    global webserver
    result = read_item_from_webserver(item_class=item_class, **kwargs)
    item = result[-1].item if result else None
    return item


def get_event_timestamp(context, load_from_web: bool = True):
    prefix = f"{context}_" if context else ""
    cached_timestamp = load_single_from_cache(
        item_class=f"internal.{prefix}event_timestamp", load_from_web=load_from_web
    )
    return cached_timestamp


def set_event_timestamp(context: str = "", sync_to_web: bool = True):
    global webserver
    current_timestamp = datetime.datetime.now()
    prefix = f"{context}_" if context else ""
    load_key = f"internal.{prefix}event_timestamp"
    if sync_to_web:
        webserver.put_secret(
            secret_name=load_key, secret_value=current_timestamp, as_pkg=True
        )
    return current_timestamp


class ModelParameters(Enum):
    WEB_CACHE_HYDRATION_OFFSET_SECONDS = 60


def check_stale_web_content(
    task,
    offset_constant: int = ModelParameters.WEB_CACHE_HYDRATION_OFFSET_SECONDS.value,
):
    task_context = f"web_cache_hydration_{task}"
    last_hydration_timestamp = (
        get_event_timestamp(context=task_context, load_from_web=False) or now()
    )
    expired = elapsed_secs(last_hydration_timestamp) >= offset_constant
    if expired:
        set_event_timestamp(context=task_context, sync_to_web=False)
    return expired


def ensure_list(item: Any) -> list:
    return item if isinstance(item, list) else [item]


def serialize(item: Any) -> bytes:
    try:
        return pickle.dumps(item)
    except Exception as e:
        error = str(e)
        print(error)
        return b""


def deserialize(item: bytes) -> Any:
    try:
        return pickle.loads(item, encoding="ISO-8859-1")
    except Exception as e:
        error = e
        return None


def write_temp_file(_data):
    rand = rand_num(size=20)
    rand_file = os.path.join(_HERE_, f"{rand}.tmps")
    with open(rand_file, "wb") as handle:
        handle.write(_data)
    return rand_file


def unpack_webserver_item(item: Any) -> Any:
    item_bytes = ensure_string(item).encode("ISO-8859-1")
    item_converted = deserialize(item_bytes)
    return item_converted if item_converted is not None else None


def re_eval(item: Any) -> Any:
    try:
        item = eval(item)
    except Exception as err:
        return item
    return re_eval(item)


def ensure_string(item: Any) -> Any:
    if isinstance(item, list):
        return [str(i) for i in item if i]
    else:
        return str(item) if item is not None else ""


def get_mongo_conn_string(mongo_conn_strings, env, docker_mongo_ip):
    mongo_conn_string = (
        mongo_conn_strings.get(env)
        if env != "local"
        else "mongodb://%s:27017/default_local" % docker_mongo_ip
    )
    return mongo_conn_string


@retry(
    Exception,
    tries=MAX_PIPE_OPERATION_RETRIES,
    delay=PIPE_OPERATION_RETRY_DELAY_SECONDS,
)
def _db_pipe_operation(environment, *args) -> Any:
    global webserver

    process_started = now()
    context, db_type, *_ = args

    query_params, mode, store_key = ARGS_BUILDERS[db_type](*args)
    _result = webserver.temp_files.get(store_key)

    if not _result or check_stale_web_content(store_key):

        pipe_cmd_template = PIPE_TEMPLATES[db_type]
        pipe_cmd = pipe_cmd_template % query_params

        if mode in SYNCHRONOUS_PIPE_OPERATIONS:
            # synchronous fetches
            raw_output = subprocess.check_output(pipe_cmd, shell=True)
            _result = re_eval(raw_output)
        else:
            # asynchronous inserts, updates and deletions
            subprocess.Popen(pipe_cmd, shell=True)
            _result = None

        # cache the result by unique args
        webserver.temp_files[store_key] = _result

    duration = elapsed_secs(process_started)
    process_log_str = f"db pipe process [environment={environment}, data_environment={db_type}, context={context}, \
                  mode={mode}] lasted: {duration} secs."
    print(process_log_str)
    return _result


def db_pipe_operation(
    environment: str, context: str, instructions: Union[dict, List[dict]]
) -> List[Any]:

    results = []

    instructions = ensure_list(instructions)

    for instruction in instructions:

        db_type = instruction.get("db_type", "mongodb")
        mode = instruction.get("mode")

        # enable output propagation
        propagate = instruction.get("propagate")
        if propagate and mode == "insert" and len(results) > 0:
            # load the last result into current process
            last_result = results[-1]
            if isinstance(last_result, str):
                last_result = [
                    item
                    for item in [re_eval(row) for row in last_result.split("\n")]
                    if item
                ]
            if db_type != "bigquery":
                instruction["query"] = last_result
            else:
                instruction["table_data"] = last_result

        args_schema = ARGS_SCHEMAS[db_type]
        args = (context, db_type)
        args += tuple(
            instruction.get(arg, data_type()) for arg, data_type in args_schema.items()
        )
        result = _db_pipe_operation(environment, *args)
        results.append(result)
    clean_temp_files()
    return results


def db_operation(args: dict, context: str, op_args: list):
    print(context, ": started")

    global webserver

    env = str(args.get("environment") or args.get("env")).lower()
    docker_mongo_ip = args.get("docker_mongo_ip")

    mongo_db_map = _MONGO_DB_MAP

    mongo_conn_strings = webserver.retrieve_secret(
        secret_name="ENV_MAP.json", decode=True, load_json=True, use_cache=True
    )

    mongo_conn_string = get_mongo_conn_string(mongo_conn_strings, env, docker_mongo_ip)

    mongo_db_name = mongo_db_map.get(env)

    _result = None

    if context == "fetch_posts_by_id":
        (post_ids,) = op_args
        collection = "content"
        (_result,) = db_pipe_operation(
            env,
            context,
            dict(
                conn_string=mongo_conn_string,
                target_db=mongo_db_name,
                target_collection=collection,
                mode="find",
                query={"_id": {"$in": ensure_string(post_ids)}},
                object_id_fields=["_id.$in"],
                db_type="pymongo",
            ),
        )

    if context == "fetch_user_posts":
        (profile_id, post_limit, ids_only) = op_args
        collection = "content"
        query_config = dict(
            conn_string=mongo_conn_string,
            target_db=mongo_db_name,
            target_collection=collection,
            mode="find",
            query={"profileId": profile_id},
            object_id_fields=["profileId"],
            db_type="pymongo",
            limit=post_limit,
        )
        if ids_only:
            query_config.update(dict(projection={"_id": 1}))
        (_result,) = db_pipe_operation(
            env,
            context,
            query_config,
        )

    if context == "fetch_random_posts":
        (exclude_ids, required_size) = op_args
        collection = "content"
        query_config = dict(
            conn_string=mongo_conn_string,
            target_db=mongo_db_name,
            target_collection=collection,
            mode="find",
            db_type="pymongo",
            limit=required_size,
        )
        if exclude_ids:
            query_config.update(
                dict(
                    query={
                        "_id": {"$nin": ensure_string(exclude_ids)},
                    },
                    object_id_fields=["_id.$nin"],
                )
            )
        (_result,) = db_pipe_operation(
            env,
            context,
            query_config,
        )
        print(f"found: {len(_result)} random posts")

    print(context, ": finished")
    return _result
