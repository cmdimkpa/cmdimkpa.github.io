from hashlib import sha256
from typing import Any, Callable, Tuple, Union
import os
from os.path import isfile
import json
from random import random
import pathlib
from datetime import datetime, timedelta
from math import log10
import pendulum


_HERE_ = pathlib.Path().parent.resolve()

_POST_REF_EVENTS = [
    "content_view_open",
    "content_view_time_on_page",
    "give_a_comment",
    "content_view_click",
]
_PROFILE_REF_EVENTS = [
    "profile_view",
    "follow_user",
]

_EXCLUSION_EVENTS = [
    "hide_content",
]

_BEHAVIOURAL_EVENT_LIST = [*_POST_REF_EVENTS, *_PROFILE_REF_EVENTS, *_EXCLUSION_EVENTS]

_AVERAGE_READ_DURATION_BY_POST_TYPE = {
    "titleVideo": 27,
    "textImage": 21,
    "titleText": 23,
    "textVideo": 16,
    "image": 13,
    "video": 14,
    "titleTextImage": 23,
    "titleTextVideo": 20,
    "text": 23,
    "titleImage": 14,
}

_MIN_READ_DURATION_OUTLIERS_BY_POST_TYPE = {
    "titleVideo": 131,
    "textImage": 105,
    "titleText": 99,
    "textVideo": 100,
    "image": 49,
    "video": 70,
    "titleTextImage": 104,
    "titleTextVideo": 101,
    "text": 105,
    "titleImage": 57,
}


def now():
    return datetime.now()


def parse_timestamp_utc(py_datetime: datetime) -> str:
    py_iso_timestamp = py_datetime.isoformat()
    _date, _time = py_iso_timestamp.split("T")
    _time, _ = _time.split(".")
    return "{} {} UTC".format(_date, _time)


def build_time_interval(**kwargs) -> Any:
    ref = now()
    target = ref - timedelta(**kwargs)
    return map(parse_timestamp_utc, sorted((ref, target)))


def get_hash(obj: Any) -> str:
    obj = str(obj).encode()
    hasher = sha256()
    hasher.update(obj)
    return hasher.hexdigest()


def rand_num(size: int = 10) -> str:
    """generate a random [10] digit string"""
    return str(random()).split(".")[1][:size]


def write_temp_file(_data, ext: str = "tmp", serializer: Callable = json.dumps):
    rand = rand_num(size=20)
    rand_file = os.path.join(_HERE_, f"{rand}.{ext}")
    with open(rand_file, "w") as handle:
        handle.write(serializer(_data))
    return rand_file


def try_delete(filepath: str):
    try:
        os.remove(filepath)
    except Exception as err:
        print(str(err))


def clean_temp_files():
    full_path = lambda p: os.path.join(_HERE_, p)
    temp_files = [
        full_path(fp)
        for fp in os.listdir(_HERE_)
        if isfile(full_path(fp)) and fp.endswith(".tmp")
    ]
    for temp_file in temp_files:
        try_delete(temp_file)


def build_event_source_query(**interval) -> str:
    """
    this function will build the source query to pull event data from BigQuery

    :interval:
        a dict containing the interval split e.g. dict(days=0, hours=10, minutes=30, seconds=0)
    """
    source_events = ",".join(
        ['"{}"'.format(event) for event in _BEHAVIOURAL_EVENT_LIST]
    )

    from_time, to_time = build_time_interval(**interval)

    source_query = f"""
        select user_id, 
           event, 
           content_id, 
           COALESCE(b.profileId, c._id) as creatorId, 
           duration 
           time, 
           JSON_EXTRACT_SCALAR(b.abstract, "$.feedType") AS feedType
        from `mixpanel_src.export_main`a
        LEFT JOIN mongodb.content b
          ON a.content_id = b._id
        LEFT JOIN mongodb.profiles c
          ON a.recipient_username = c.username
        WHERE event in ({source_events})
        AND time BETWEEN TIMESTAMP('{from_time}') and TIMESTAMP('{to_time}')
    """
    return source_query


def elapsed_secs(timestamp: datetime) -> float:
    return (now() - timestamp).total_seconds()


def standardize_timestamp(timestamp: str) -> str:
    return "T".join(timestamp.split(" ")[:2])


def get_recency_score(timestamp: Union[datetime, str]) -> float:
    """
    Convert a timestamp to a score proportional to the number of seconds since that timestamp.
    The closer the timestamp is to the current time, the better the score will be.
    The score is a number between 0 and 1.
    """
    _timestamp = (
        timestamp
        if isinstance(timestamp, datetime)
        else pendulum.parse(standardize_timestamp(timestamp=timestamp)).replace(
            tzinfo=None
        )
    )
    _elapsed_secs = elapsed_secs(_timestamp)
    _log_elapsed_secs = log10(_elapsed_secs)
    recency_score = 1 / _log_elapsed_secs
    return recency_score
