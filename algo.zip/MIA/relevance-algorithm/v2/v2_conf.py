from http import HTTPStatus
import datetime
import os

from v2_shared import get_hash, write_temp_file, _HERE_

_EVENT_LIMIT = 100000

_EVENT_FILTER = None

_RANDOM_POST_LIMIT = 1000

_RECOMMENDED_POST_THRESHOLD = 50

_DEFAULT_EVENT_SCAN_MINUTES = 5

_WEBSERVER_HOST_ADDRESS = "35.225.91.166:81"

_TEST_API_KEY = "f50bde790c602643318c932c7ab236b9"

_MONGO_DB_MAP = {
    "integration": "taringa-platform-development",
    "stage": "taringa-platform-staging",
    "prod": "taringa-platform-prod",
    "local": "default_local",
}

OBJECT_ID_FIELDS = [
    "_id",
    "accountId",
    "profileId",
    "userId",
    "authorId",
    "contentId",
]

MODERATION_REJECT_STATES = ["banned"]

POST_ACCEPT_STATES = ["published"]
_BATCH_OP_MODES = ["random-train", "event-train", "fetch-v2-index", "fetch-v2-corpus"]
_BATCH_ENVS = ["prod", "stage", "integration"]

MAX_PIPE_OPERATION_RETRIES = 10
PIPE_OPERATION_RETRY_DELAY_SECONDS = 5

SYNCHRONOUS_PIPE_OPERATIONS = ["find", "find_one", "export"]

ENV_BASE_URLS = {
    "non-prod": "http://api.mia-%s.taringa.net/relevance-algorithm/",
    "prod": "http://api.app.taringa.net/relevance-algorithm/",
}

UTIL_TASKS = [
    "force-train-model",
    "pull-data",
    "local-train-model",
    "mark-unmark-ambassadors",
    "moderation-test",
]

SUPPORTED_TASKS = [
    "fetch-creators",
    "fetch-posts",
    "fetch-errors",
    "fetch-logs",
    *UTIL_TASKS,
]


BAD_STATUS = [
    HTTPStatus.SERVICE_UNAVAILABLE,
    HTTPStatus.FORBIDDEN,
    HTTPStatus.UNAUTHORIZED,
    HTTPStatus.BAD_REQUEST,
    HTTPStatus.NOT_FOUND,
]

path_prepend = ".." if "v2" in str(_HERE_) else "."

PIPE_RUNNERS = {
    "mongodb": os.path.join(
        _HERE_, f"{path_prepend}/server/utils/data-manager/pipe.js"
    ),
    "pymongo": os.path.join(
        _HERE_, f"{path_prepend}/server/utils/data-manager/pipe.py"
    ),
}

_args_schema = {
    "conn_string": str,
    "target_db": str,
    "target_collection": str,
    "mode": str,
    "query": dict,
    "projection": dict,
    "filter": dict,
    "patch": dict,
    "object_id_fields": list,
    "date_fields": list,
    "limit": int,
}

ARGS_SCHEMAS = {"mongodb": _args_schema, "pymongo": _args_schema}

PIPE_TEMPLATES = dict(
    mongodb='node %s --connection_string="%s" \
                            --database_name="%s" --collection_name="%s" --mode="%s" --query="%s" --projection="%s" \
                            --filter="%s" --patch="%s" --object_id_fields="%s" --date_fields="%s" --limit=%d',
    pymongo='python3 %s --connection-string="%s" \
                            --database-name="%s" --collection-name="%s" --mode="%s" --query="%s" --projection="%s" \
                            --filter="%s" --patch="%s" --oids-filepath="%s" --date-filepath="%s" --limit=%d',
    mixpanel='node %s --secret_object="%s" --from_date="%s" --to_date="%s" \
                         --event_list="%s" --event_limit="%s" --event_filter="%s" --mode="%s"',
)


def serialize_fields(item: dict) -> dict:

    available_object_id_fields = [field for field in OBJECT_ID_FIELDS if field in item]

    for field in available_object_id_fields:
        object_id = item[field]
        item[field] = str(object_id)

    for field in item:
        field_value = item[field]
        if isinstance(field_value, datetime.datetime):
            item[field] = field_value.isoformat()

    return item


def build_mongodb_args(*args):
    (
        context,
        db_type,
        conn_string,
        target_db,
        target_collection,
        mode,
        query,
        projection,
        filter,
        patch,
        object_id_fields,
        date_fields,
        limit,
    ) = args

    args_hash = get_hash(args)
    store_key = f"db_pipe_result_{args_hash}"

    if context == "write_mongo_vector":
        transformed = []
        for item in query:
            objects = item["item"]
            item["item"] = serialize_fields(objects)
            transformed.append(item)
        query = transformed

    query_str = write_temp_file(query)
    projection_str = write_temp_file(projection)
    filter_str = write_temp_file(filter)
    patch_str = write_temp_file(patch)
    object_id_fields_str = write_temp_file(object_id_fields)
    date_fields_str = write_temp_file(date_fields)

    query_params = (
        PIPE_RUNNERS[db_type],
        conn_string,
        target_db,
        target_collection,
        mode,
        query_str,
        projection_str,
        filter_str,
        patch_str,
        object_id_fields_str,
        date_fields_str,
        limit,
    )

    return query_params, mode, store_key


ARGS_BUILDERS = {
    "mongodb": build_mongodb_args,
    "pymongo": build_mongodb_args,
}
