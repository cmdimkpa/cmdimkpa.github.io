TEST_API_KEY = "f50bde790c602643318c932c7ab236b9"
TEST_USER_ID = "641b0025bcd2a12b766d35b9"

STAGE_TEST_POST_ID = "640255b0df401d001267602a"
STAGE_TEST_POST_ID_2 = "64025530df401d0012676028"

SAMPLE_ENGLISH_POST = "We will never make a journey of a thousand miles by fretting about how \
                       long it will take or how hard it will be 😋."

SAMPLE_SPANISH_POST = "Mas Vale Pájaro en Mano Que Cien Volando 🕊️"

WEBSERVER_TEST_SECRET_NAME = "Some test secret"
WEBSERVER_TEST_SECRET_VALUE = "Some test secret value"

SAMPLE_EVENTS_CONTENT_VIEW_OPEN = [
    {
        "user_id": "647b7ed5753c32a473133336",
        "event": "content_view_open",
        "content_id": "64835aae844d11a5993429c7",
        "creatorId": "641b21e5bcd2a12b766d395c",
        "time": None,
        "feedType": "titleTextImage",
    },
    {
        "user_id": "647b7ed5753c32a473133336",
        "event": "content_view_open",
        "content_id": "6483b327bdf6ccc5b6311508",
        "creatorId": "647c8e7684120c6c2ddfef41",
        "time": None,
        "feedType": "titleTextImage",
    },
    {
        "user_id": "647b7ed5753c32a473133336",
        "event": "content_view_open",
        "content_id": "64839e4a844d11a599342b22",
        "creatorId": "64524dd18b5abd15603dae22",
        "time": None,
        "feedType": "titleImage",
    },
]

SAMPLE_EVENTS_CONTENT_VIEW_TIME_ON_PAGE = [
    {
        "user_id": "647b7ed5753c32a473133336",
        "event": "content_view_time_on_page",
        "content_id": "64835aae844d11a5993429c7",
        "creatorId": "641b21e5bcd2a12b766d395c",
        "time": "33",
        "feedType": "titleTextImage",
    },
    {
        "user_id": "647b7ed5753c32a473133336",
        "event": "content_view_time_on_page",
        "content_id": "6483b327bdf6ccc5b6311508",
        "creatorId": "647c8e7684120c6c2ddfef41",
        "time": "26",
        "feedType": "titleTextImage",
    },
    {
        "user_id": "647b7ed5753c32a473133336",
        "event": "content_view_time_on_page",
        "content_id": "64839e4a844d11a599342b22",
        "creatorId": "64524dd18b5abd15603dae22",
        "time": "9",
        "feedType": "titleImage",
    },
]

SAMPLE_EVENTS_GIVE_A_COMMENT = [
    {
        "user_id": "647b7ed5753c32a473133336",
        "event": "give_a_comment",
        "content_id": "64835aae844d11a5993429c7",
        "creatorId": "641b21e5bcd2a12b766d395c",
        "time": None,
        "feedType": "titleTextImage",
    },
    {
        "user_id": "647b7ed5753c32a473133336",
        "event": "give_a_comment",
        "content_id": "6483b327bdf6ccc5b6311508",
        "creatorId": "647c8e7684120c6c2ddfef41",
        "time": None,
        "feedType": "titleTextImage",
    },
    {
        "user_id": "647a7e5184120c6c2ddfa4b2",
        "event": "give_a_comment",
        "content_id": "6483d401a30bd08c0bef6df2",
        "creatorId": "644ead3793e9b49222721997",
        "time": None,
        "feedType": "textImage",
    },
]

SAMPLE_EVENTS_PROFILE_VIEW = [
    {
        "user_id": "647a7e5184120c6c2ddfa4b2",
        "event": "profile_view",
        "content_id": None,
        "creatorId": "644ead3793e9b49222721997",
        "time": None,
        "feedType": None,
    },
    {
        "user_id": "647a7e5184120c6c2ddfa4b2",
        "event": "profile_view",
        "content_id": None,
        "creatorId": "6451f86c93e9b49222723b56",
        "time": None,
        "feedType": None,
    },
    {
        "user_id": "6484590d84120c6c2de095af",
        "event": "profile_view",
        "content_id": None,
        "creatorId": "641b304dbcd2a12b766d3ad5",
        "time": None,
        "feedType": None,
    },
]

SAMPLE_EVENTS_FOLLOW_USER = [
    {
        "user_id": "647a7e5184120c6c2ddfa4b2",
        "event": "follow_user",
        "content_id": None,
        "creatorId": "644ead3793e9b49222721997",
        "time": None,
        "feedType": None,
    },
    {
        "user_id": "646662e07d05c1fda2c48500",
        "event": "follow_user",
        "content_id": None,
        "creatorId": "6459abc18b5abd15603e4214",
        "time": None,
        "feedType": None,
    },
    {
        "user_id": "646662e07d05c1fda2c48500",
        "event": "follow_user",
        "content_id": None,
        "creatorId": "647937da84120c6c2ddf542c",
        "time": None,
        "feedType": None,
    },
]

SAMPLE_EVENTS_CONTENT_VIEW_CLICK = [
    {
        "user_id": "6479075f753c32a473128dc8",
        "event": "content_view_click",
        "content_id": "6483bd4abdf6ccc5b6311551",
        "creatorId": "641b304dbcd2a12b766d3ad5",
        "time": None,
        "feedType": "titleTextImage",
    },
    {
        "user_id": "647927a6753c32a47312a7d5",
        "event": "content_view_click",
        "content_id": "64833640bdf6ccc5b631124e",
        "creatorId": "641b96ddbcd2a12b766d49ab",
        "time": None,
        "feedType": "titleTextImage",
    },
    {
        "user_id": "641abe70bcd2a12b766d3153",
        "event": "content_view_click",
        "content_id": "6483bd4abdf6ccc5b6311551",
        "creatorId": "641b304dbcd2a12b766d3ad5",
        "time": None,
        "feedType": "titleTextImage",
    },
]
