import pytest

import os
import sys
import pathlib
from random import random

_HERE_ = pathlib.Path().parent.resolve()
_MAIN_DIR_ = os.path.join(_HERE_, "./")
sys.path.append(_MAIN_DIR_)

from v2_io import (
    fetch_posts_content,
    get_bigquery_client,
    source_events_by_interval,
    fetch_user_posts,
    build_training_schedule_from_events,
    process_post_ref_event,
    process_profile_ref_event,
    is_significant_post_read,
)
from v2_index import (
    clean_and_tokenize,
    train_semantic_index,
    read_corpus_size,
    get_env_based_key,
    recommend_posts_handler,
)
from v2_redis import redis, CacheInterface
from test_conf import (
    TEST_API_KEY,
    TEST_USER_ID,
    SAMPLE_ENGLISH_POST,
    SAMPLE_SPANISH_POST,
    STAGE_TEST_POST_ID,
    STAGE_TEST_POST_ID_2,
    WEBSERVER_TEST_SECRET_NAME,
    WEBSERVER_TEST_SECRET_VALUE,
    SAMPLE_EVENTS_CONTENT_VIEW_OPEN,
    SAMPLE_EVENTS_CONTENT_VIEW_TIME_ON_PAGE,
    SAMPLE_EVENTS_GIVE_A_COMMENT,
    SAMPLE_EVENTS_PROFILE_VIEW,
    SAMPLE_EVENTS_FOLLOW_USER,
    SAMPLE_EVENTS_CONTENT_VIEW_CLICK,
)
from v2_utils import webserver
from v2_conf import _WEBSERVER_HOST_ADDRESS
from v2_shared import (
    build_event_source_query,
    get_recency_score,
    now,
    timedelta,
    _BEHAVIOURAL_EVENT_LIST,
    _AVERAGE_READ_DURATION_BY_POST_TYPE,
    _MIN_READ_DURATION_OUTLIERS_BY_POST_TYPE,
)

os.environ["API_KEY"] = TEST_API_KEY
cache = CacheInterface()


def test_initialize_cache_interface():
    assert cache
    cache.connect()
    assert isinstance(cache.client, redis.StrictRedis)


def test_insert_and_retrieve_from_redis():
    # insert test data
    insert_profile = dict(
        dim_id="test dimension id",
        dim_data="test dimension data",
        metadata=[1, "test query id"],
    )
    cache.insert(**insert_profile)
    # retrieve test data
    retrieve_profile = dict(
        dim_id="test dimension id",
        query_id="test query id",
        page_size=1,
        current_page=1,
    )
    (result,), _ = cache.retrieve(**retrieve_profile)
    assert result == "test dimension data"


def test_index_clean_and_tokenize_english():
    assert clean_and_tokenize(SAMPLE_ENGLISH_POST) == {
        "miles",
        "hard",
        "make",
        "journey",
        "never",
        "😋",
        "thousand",
        "long",
        "take",
        "fretting",
    }


def test_index_clean_and_tokenize_spanish():
    assert clean_and_tokenize(SAMPLE_SPANISH_POST) == {
        "vale",
        "mano",
        "volando",
        "cien",
        "pájaro",
        "🕊️",
    }


def test_fetch_post_content():
    ((post_id, post_text, post_recency_score),) = fetch_posts_content(
        post_ids=[STAGE_TEST_POST_ID], env="stage"
    )
    assert post_id == STAGE_TEST_POST_ID
    assert post_text == "Gggggg"
    assert post_recency_score < 0.14212641476521867


def test_update_semantic_index():
    test_post_ids = [STAGE_TEST_POST_ID_2, STAGE_TEST_POST_ID]
    index, _ = train_semantic_index(env="stage", post_ids=test_post_ids)
    assert index["columns"][:2] == test_post_ids


def test_fetch_corpus():
    env = "stage"
    retrieve_profile = dict(
        dim_id=get_env_based_key(env=env, key="V2_SYS_CORPUS"),
        query_id=env,
        page_size=read_corpus_size(env=env)[0],
        current_page=1,
    )
    env_corpus, _ = cache.retrieve(**retrieve_profile)
    assert len(env_corpus) > 0
    assert len(env_corpus[0]) == 3
    sample_post_id, sample_para, sample_para_hash = env_corpus[0]
    assert sample_post_id == STAGE_TEST_POST_ID_2
    assert sample_para == "yyh"
    assert (
        sample_para_hash
        == "ff5946b21fbca94fabd80bb62c0126966e194af9b91363e26a11ac8893adb06d"
    )


def test_post_recommendations():
    test_post_ids = [STAGE_TEST_POST_ID, STAGE_TEST_POST_ID_2]
    env = "stage"
    recommended_posts = recommend_posts_handler(
        env=env, post_ids=test_post_ids, train_index=True
    )
    assert recommended_posts == test_post_ids


def test_webserver_initialization():
    assert webserver
    assert _WEBSERVER_HOST_ADDRESS in webserver.secrets_url_format


def test_webserver_save_retrieve_data():
    webserver.put_secret(
        secret_name=WEBSERVER_TEST_SECRET_NAME, secret_value=WEBSERVER_TEST_SECRET_VALUE
    )
    retrieved = webserver.retrieve_secret(
        secret_name=WEBSERVER_TEST_SECRET_NAME,
        use_cache=True,
        decode=True,
        load_json=True,
    )
    assert retrieved == WEBSERVER_TEST_SECRET_VALUE


def test_webserver_caching():
    assert (
        webserver.temp_files[WEBSERVER_TEST_SECRET_NAME] == WEBSERVER_TEST_SECRET_VALUE
    )


def test_build_event_source_query():
    source_query = build_event_source_query()
    assert source_query
    assert len(source_query) == 674


def test_get_bigquery_client():
    bq_client = get_bigquery_client()
    assert bq_client


def test_source_bigquery_events():
    interval = dict(days=1)
    events = source_events_by_interval(**interval)
    assert events
    event_types = [_ for _ in events]
    sample_event_type = event_types[0]
    sample_event = events[sample_event_type][0]
    assert isinstance(sample_event, dict)
    assert sample_event_type in _BEHAVIOURAL_EVENT_LIST


def test_fetch_user_posts():
    user_post_ids = fetch_user_posts(user_id=TEST_USER_ID, ids_only=True)
    sample_user_post_id = user_post_ids[0]
    assert len(user_post_ids) > 0
    assert isinstance(sample_user_post_id, str)


def test_process_post_ref_event():
    sample_event_with_duration = SAMPLE_EVENTS_CONTENT_VIEW_TIME_ON_PAGE[0]
    post_ids, exclusion_set = process_post_ref_event(
        post_ids=set(), event=sample_event_with_duration, exclusion_set=set()
    )
    assert post_ids
    assert exclusion_set
    assert isinstance(post_ids, set)
    assert isinstance(exclusion_set, set)
    assert post_ids == exclusion_set


def test_process_profile_ref_event():
    sample_profile_event = SAMPLE_EVENTS_PROFILE_VIEW[0]
    post_ids, exclusion_set = process_profile_ref_event(
        post_ids=set(), event=sample_profile_event, exclusion_set=set()
    )
    assert post_ids
    assert exclusion_set == set()
    assert isinstance(post_ids, set)


def test_post_read_significance():

    test_post_type = "video"
    average_post_read_time = _AVERAGE_READ_DURATION_BY_POST_TYPE[test_post_type]
    lowest_outlier_post_read_time = _MIN_READ_DURATION_OUTLIERS_BY_POST_TYPE[
        test_post_type
    ]

    assert not is_significant_post_read(
        post_type=test_post_type, duration=average_post_read_time
    )

    assert not is_significant_post_read(
        post_type=test_post_type, duration=average_post_read_time - 1
    )

    assert is_significant_post_read(
        post_type=test_post_type, duration=average_post_read_time + 1
    )

    assert not is_significant_post_read(
        post_type=test_post_type, duration=lowest_outlier_post_read_time
    )

    assert not is_significant_post_read(
        post_type=test_post_type, duration=lowest_outlier_post_read_time + 1
    )

    assert is_significant_post_read(
        post_type=test_post_type, duration=lowest_outlier_post_read_time - 1
    )

    good_duration = average_post_read_time + random() * (
        lowest_outlier_post_read_time - average_post_read_time
    )

    assert is_significant_post_read(post_type=test_post_type, duration=good_duration)


def test_build_training_schedule_from_events():
    test_aggregated_events = dict(
        content_view_open=SAMPLE_EVENTS_CONTENT_VIEW_OPEN,
        content_view_time_on_page=SAMPLE_EVENTS_CONTENT_VIEW_TIME_ON_PAGE,
        give_a_comment=SAMPLE_EVENTS_GIVE_A_COMMENT,
        profile_view=SAMPLE_EVENTS_PROFILE_VIEW,
        follow_user=SAMPLE_EVENTS_FOLLOW_USER,
        content_view_click=SAMPLE_EVENTS_CONTENT_VIEW_CLICK,
    )
    test_training_schedule, exclusion_set = build_training_schedule_from_events(
        test_aggregated_events
    )
    test_user = [_ for _ in test_training_schedule][0]
    test_post_id = list(test_training_schedule[test_user])[0]
    assert test_training_schedule
    assert exclusion_set
    assert isinstance(test_training_schedule, dict)
    assert isinstance(exclusion_set, set)
    assert isinstance(test_user, str)
    assert isinstance(test_post_id, str)


def test_recency_score():
    baseline_point_in_time_score = get_recency_score("2023-04-27 19:23:59 UTC")
    one_month_before_baseline_score = get_recency_score("2023-03-27 19:23:59 UTC")
    ten_seconds_ago_score = get_recency_score(now() - timedelta(seconds=10))
    assert 0 < baseline_point_in_time_score < 1
    assert 0 < one_month_before_baseline_score < 1
    assert 0 < ten_seconds_ago_score < 1
    assert baseline_point_in_time_score > one_month_before_baseline_score
    assert ten_seconds_ago_score > baseline_point_in_time_score
