# Relevance Algorithm (Creator & Feed Suggestions)

## command to build docker image

`docker build -t creator_api .`

## command to run with docker

`docker run --rm -it --name discovery_feed -p 8080:5000 creator_api:latest`

## V2 Reference (WIP)

<img src="docs/v2_architecture.png" alt="V2 architecture">

In V2, our relevance algorithm works based on engagement and interactions:

- If a user engages with a post, then other posts similar to that post are recommended for that user
- If a user views a creator's profile or follows a creator, that creator's recent posts as well as posts similar to those posts, will be recommended for the user

Post similarity is computed based TF-IDF vectors, and the indexes are stored in Redis on the orchestration server.

## V1 Reference

### Architecture (Infrastructure)

<img src="docs/model_infra.png" alt="model infrastructure">

### Weight-product Sum (WPS)

Given a distribution of factors and factor weights, our ranking systems compute the factors by aggregating data (usually post and profile data) for each candidate. Once the factors are computed, we multiply in turn by the pre-defined weights and reduce by summing. 

Once reduced, candidate scores are normalized based on the maximum scores in the network. We then rank and display the suggestions in descending order of this WPS.

### Linspace Interpolation

While serving the feed, we have to factor-in recency of a post in addition to its computed relevance (WPS) score. To do this we need a convenient and fast way of normalizing timestamps between 0 and 1.

We can achieve this using _linspace interpolation_:

<img src="docs/linspace_interpolation.png" alt="linspace interpolation">

This means that the final normalized value of a timestamp is dependent on its intermediate value (usually the _log_ of seconds elapsed since the timestamp), the _max_ and _min_ intermediate values seen in the network, and some constant of proportionality _K_ which we are free to choose arbitrarily.

The final post score will then be the _geometric mean_ of the WPS and this value.

## External Attribution

### Running Redis in container
Some code was taken from: https://github.com/sameersbn/docker-redis and added to our Dockerfile