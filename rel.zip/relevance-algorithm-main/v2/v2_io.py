from typing import Any, List, Union, Tuple
import os
from google.cloud import bigquery

from v2_conf import _RANDOM_POST_LIMIT, _RECOMMENDED_POST_THRESHOLD
from v2_utils import db_operation, webserver
from v2_shared import (
    build_event_source_query,
    get_recency_score,
    _POST_REF_EVENTS,
    _PROFILE_REF_EVENTS,
    _AVERAGE_READ_DURATION_BY_POST_TYPE,
    _MIN_READ_DURATION_OUTLIERS_BY_POST_TYPE,
)


def is_significant_post_read(post_type: str, duration: Union[str, int, None]):
    if duration is not None:
        duration = int(duration)
        average_read_duration = _AVERAGE_READ_DURATION_BY_POST_TYPE[post_type]
        min_outlier_read_duration = _MIN_READ_DURATION_OUTLIERS_BY_POST_TYPE[post_type]
        return average_read_duration < duration < min_outlier_read_duration
    else:
        return False


def get_post_text(post: dict) -> Any:
    text = (post.get("abstract", {}) or {}).get("text")
    title = post.get("title")
    return (text or title) if post.get("status") == "published" else None


def fetch_user_posts(
    user_id: str,
    post_count: int = _RECOMMENDED_POST_THRESHOLD,
    ids_only: bool = False,
) -> List[Any]:
    posts = db_operation(
        args=dict(env="prod"),
        context="fetch_user_posts",
        op_args=[user_id, post_count, ids_only],
    )
    if ids_only:
        posts = [str(post["_id"]) for post in posts]
    return posts


def fetch_posts_content(post_ids, **kwargs):
    context, op_args = (
        ("fetch_posts_by_id", [post_ids])
        if post_ids
        else ("fetch_random_posts", [None, _RANDOM_POST_LIMIT])
    )
    posts = db_operation(
        args=kwargs,
        context=context,
        op_args=op_args,
    )
    return [
        (str(post["_id"]), get_post_text(post), get_recency_score(post["updatedAt"]))
        for post in posts
        if get_post_text(post)
    ]


def get_bigquery_client():
    secret_path = webserver.temp_files.get("svc.json")
    if not secret_path:
        webserver.write_temp_secret("svc.json")
        secret_path = webserver.temp_files.get("svc.json")
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = secret_path
    client = bigquery.Client()
    return client


def source_events_by_interval(**interval):
    """
    fetch events that have been generated in the last [interval]
    from BigQuery
    """

    source_query = build_event_source_query(**interval)
    bq_client = get_bigquery_client()

    query_job = bq_client.query(source_query)
    rows = query_job.result()
    aggregated_events = {}

    for row in rows:
        event = dict(row.items())
        event_type = event["event"]
        if event_type in aggregated_events:
            aggregated_events[event_type].append(event)
        else:
            aggregated_events[event_type] = [event]

    webserver.delete_secret("svc.json")
    return aggregated_events


def process_post_ref_event(
    post_ids: set, event: dict, exclusion_set: set
) -> Tuple[set, set]:
    feed_type = event["feedType"]
    feed_type_eligible = "text" in str(feed_type).lower()

    duration = event["time"]
    duration_eligible = (
        is_significant_post_read(post_type=feed_type, duration=duration)
        if feed_type is not None
        else False
    )

    eligible = (
        feed_type_eligible
        if not duration
        else (feed_type_eligible and duration_eligible)
    )

    if eligible:
        post_id = event["content_id"]
        post_ids = {*post_ids, post_id}
        exclusion_set = {*exclusion_set, post_id}
    return post_ids, exclusion_set


def process_profile_ref_event(
    post_ids: set, event: dict, exclusion_set: set
) -> Tuple[set, set]:
    creator_id = event["creatorId"]
    new_post_ids = fetch_user_posts(user_id=creator_id, ids_only=True)
    post_ids = {*post_ids, *new_post_ids}
    return post_ids, exclusion_set


_EVENT_PROCESSING_INSTRUCTIONS = [
    {"event_group": _POST_REF_EVENTS, "event_handler": process_post_ref_event},
    {"event_group": _PROFILE_REF_EVENTS, "event_handler": process_profile_ref_event},
]


def build_training_schedule_from_events(aggregated_events: dict) -> Tuple[dict, set]:

    training_schedule = dict()
    exclusion_set = set()

    for instruction in _EVENT_PROCESSING_INSTRUCTIONS:
        event_group = instruction["event_group"]
        event_handler = instruction["event_handler"]
        for event_type in event_group:
            events = aggregated_events.get(event_type, [])
            for event in events:
                user_id = event["user_id"]
                if user_id in training_schedule:
                    post_ids = training_schedule[user_id]
                else:
                    post_ids = set()
                post_ids, exclusion_set = event_handler(
                    post_ids=post_ids, event=event, exclusion_set=exclusion_set
                )
                training_schedule[user_id] = post_ids

    return training_schedule, exclusion_set
