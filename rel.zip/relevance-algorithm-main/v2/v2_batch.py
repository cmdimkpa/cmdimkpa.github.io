import argparse
from v2_index import train_semantic_index, recommend_posts_handler
from v2_io import source_events_by_interval, build_training_schedule_from_events
from v2_conf import _DEFAULT_EVENT_SCAN_MINUTES

_OP_MODES = ["random-train", "event-train"]
_ENVS = ["prod", "stage", "integration"]

parser = argparse.ArgumentParser()

parser.add_argument(
    "--mode",
    "-m",
    choices=_OP_MODES,
    required=True,
    type=str,
    help="operational mode",
)
parser.add_argument(
    "--environment",
    "-env",
    choices=_ENVS,
    required=True,
    type=str,
    help="target data environment",
)

parser.add_argument(
    "--scan-minutes",
    "-sm",
    type=int,
    default=_DEFAULT_EVENT_SCAN_MINUTES,
    help="minutes to scan for events",
)

parser.add_argument(
    "--wait-result",
    "-wr",
    type=str,
    help="external variable",
)


def random_trainer(context):
    train_semantic_index(env=context.environment)


def event_trainer(context):
    new_events = source_events_by_interval(minutes=context.scan_minutes)
    training_schedule, exclusion_set = build_training_schedule_from_events(new_events)
    recommendations = dict()
    for user_id, post_ids in training_schedule.items():
        recommended_posts = recommend_posts_handler(
            env="prod",
            post_ids=list(post_ids),
            train_index=True,
            exclude_post_ids=list(exclusion_set),
        )
        recommendations[user_id] = recommended_posts
    print(recommendations)


CONTEXT_HANDLER = {
    "random-train": random_trainer,
    "event-train": event_trainer,
}


if __name__ == "__main__":
    args = parser.parse_args()
    CONTEXT_HANDLER[args.mode](args)
