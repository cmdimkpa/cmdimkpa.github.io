import json
import os
from typing import Any, List, Tuple, Union
import redis
from pottery import Redlock
from retry import retry

_REDIS_HOST = os.environ.get("REDIS_HOST", "localhost")
_REDIS_PORT = int(os.environ.get("REDIS_PORT", "6379"))
_REDIS_DB = int(os.environ.get("REDIS_DB", 0))

# number of times to retry a Redis call before hanging up
_REDIS_CALL_MAX_RETRIES = int(os.environ.get("REDIS_CALL_MAX_RETRIES", 10))

# number of seconds to wait before retrying a Redis call
_REDIS_CALL_RETRY_WAIT = int(os.environ.get("REDIS_CALL_RETRY_WAIT", 1))

# number of seconds to wait for lock acquisition before raising error
_CACHE_ACQUIRE_LOCK_TIMEOUT = int(os.environ.get("CACHE_ACQUIRE_LOCK_TIMEOUT", 30))

# the timeout in seconds by which to automatically release the Redlock
_CACHE_REDLOCK_AUTO_RELEASE_TIME = int(
    os.environ.get("CACHE_REDLOCK_AUTO_RELEASE_TIME", 60)
)

_REDIS_IMPL = redis.StrictRedis

_REDIS_PASSWORD = None


def build_redis_client_connection_args() -> dict:
    """Build redis connection args based on SSL config"""
    connection_args = dict(
        host=_REDIS_HOST, port=_REDIS_PORT, password=_REDIS_PASSWORD, db=_REDIS_DB
    )
    return connection_args


redis_connection_args = build_redis_client_connection_args()

# this mapping is useful when handling data from non-Python sources
false = False
true = True
null = undefined = None


def build_insert_context(
    dim_id: str, query_id: str, results_to_cache: List[Any], total_results: int
) -> dict:
    """build a cache insert context"""
    results = (
        results_to_cache if isinstance(results_to_cache, list) else [results_to_cache]
    )
    return dict(
        dim_id=dim_id,
        dim_data=results,
        metadata=[total_results, query_id],
    )


def compute_page_range(page_size, current_page):
    """calculate the zero-indexed cache boundaries of a requested page"""
    from_index = (current_page - 1) * page_size
    to_index = current_page * page_size - 1
    return from_index, to_index


def prepare_object_for_cache_insert(
    obj: Any,
    score: int = 0,
    as_tuple=False,
) -> Union[dict, tuple]:
    """
    prepare a single object to be inserted into the cache:
    because we are inserting into a sorted set, we need a mapping
    with a hashable key (made by obtaining a string dump of the object) and
    a score, which defaults to 0.
    """
    return {json.dumps(obj): score} if not as_tuple else (json.dumps(obj), score)


def prepare_array_for_cache_insert(arr: list) -> dict:
    """
    prepare an array of items to be inserted into the cache:
    here we create a mapping with the string dump of each item in the array as
    a hashable key and its index position in the array as its score.
    This is done in order to preserve insertion order upon retrieval.
    """
    entries = []
    _index = -1
    for item in arr:
        _index += 1
        entry = prepare_object_for_cache_insert(
            obj=item,
            score=_index,
            as_tuple=True,
        )
        entries.append(entry)
    insert_package = dict(entries)
    return insert_package


def cache_marshaling(obj: dict) -> dict:
    """marshal objects prior to cache insertion"""

    def _transform(item: Any) -> Any:
        """
        ensure items are JSON-serializable by
        marshaling to base forms where possible
        """
        try:
            item = item.to_dict()
        except AttributeError:
            pass
        return item

    return {f: _transform(obj[f]) for f in obj}


def deserialize(item: Union[str, bytes]) -> Any:
    """recover original object from serialized form"""
    return json.loads(item)


def process_raw_result(raw_result):
    """process raw strings retrieved from Redis into base objects"""
    if raw_result is not None:
        result_string = (
            raw_result.decode() if isinstance(raw_result, bytes) else raw_result
        )
        result = deserialize(result_string)
    else:
        result = None
    return result


class CacheInterface(object):
    """
    A data interface for the Redis cache.

    :argument connection_args
        dict of connection arguments to pass to the Redis client.

    :argument context_key
        the context key is used as a prefix for all other auto-generated keys.

    """

    def __init__(
        self,
        connection_args: dict = redis_connection_args,
        context_key: str = "",
    ) -> None:
        self.connection_args = connection_args
        self.backend = None
        self.client = None
        self.context_key = context_key

    def connect(self):
        """enable lazy initialization of the client"""
        if not self.client:
            self.backend = _REDIS_IMPL
            self.client = self.backend(**self.connection_args)
        return self

    def get_lock(self, context: str, tag: str = "lock") -> Any:
        """instantiate new Redlock object to protect a resource"""
        self.connect()
        self.update_context_key(context)
        context_lock_key = self.build_insert_key(tag=tag)
        context_lock = Redlock(
            key=context_lock_key,
            masters={self.client},
            context_manager_blocking=True,
            context_manager_timeout=_CACHE_ACQUIRE_LOCK_TIMEOUT,
            auto_release_time=_CACHE_REDLOCK_AUTO_RELEASE_TIME,
        )
        return context_lock

    @retry(tries=_REDIS_CALL_MAX_RETRIES, delay=_REDIS_CALL_RETRY_WAIT, logger=None)
    def getter(self, key: str, page_size: int, current_page: int) -> List[Any]:
        """
        Fetch a result page from a Redis sorted set given a key as well as
        pagination parameters from the client.
        """
        from_index, to_index = compute_page_range(page_size, current_page)
        result_set = self.connect().client.zrange(key, from_index, to_index)
        page = [process_raw_result(item) for item in result_set]
        return page

    @retry(tries=_REDIS_CALL_MAX_RETRIES, delay=_REDIS_CALL_RETRY_WAIT, logger=None)
    def setter(self, key: str, items: Any) -> None:
        """
        Update a sorted set in Redis located at the given key with the given items.
        The list of items is transformed into a dictionary and inserted at once.
        """
        items = items if isinstance(items, list) else [items]
        if items:
            self.connect()
            # clear the cache before inserting new items
            self.client.delete(key)
            # prepare and write items to cache
            insert_package = prepare_array_for_cache_insert(items)
            self.client.zadd(key, insert_package, nx=True)

    def update_context_key(self, context_key: str) -> None:
        """update the context key"""
        self.context_key = context_key

    def build_insert_key(self, tag: str = "dim_data", iter_key: int = 0) -> str:
        """
        build a custom insert key

        :argument tag
            this is a descriptive text to further contextualize the cached data

        :argument iter_key
            this is intended to be a dynamic key (integer) that ensures uniqueness for the insert key
        """
        insert_key = f"{self.context_key}_{tag}_{iter_key}"
        return insert_key

    def insert(
        self,
        dim_id: str,
        dim_data: List[Any],
        metadata: List[Any] = [],
    ) -> None:
        """insert dimension data and metadata into the cache based on the dim_id"""
        # update context key
        self.update_context_key(dim_id)
        # store metadata
        metadata_insert_key = self.build_insert_key(tag="metadata")
        self.setter(metadata_insert_key, metadata)
        # store results (if result is empty it won't get stored but the metadata will)
        insert_key = self.build_insert_key()
        self.setter(insert_key, dim_data)

    def retrieve(
        self,
        dim_id: str,
        query_id: str,
        page_size: int,
        current_page: int,
    ) -> Tuple[List[Any], List[Any]]:
        """
        Retrieve cached results and metadata based on the dim_id, query_id and
        pagination parameters sent from the client.
        """
        # update context key
        self.update_context_key(dim_id)
        # fetch search metadata (for simplicity, page_size = number of metadata items stored)
        metadata_insert_key = self.build_insert_key(tag="metadata")
        metadata = self.getter(key=metadata_insert_key, page_size=2, current_page=1)
        if metadata:
            # check that last cached items are for the requested search
            cached_total_results, cached_query_id = metadata
            if cached_query_id == query_id:
                # fetch requested page
                page_insert_key = self.build_insert_key()
                cached_page = (
                    self.getter(
                        key=page_insert_key,
                        page_size=page_size,
                        current_page=current_page,
                    )
                    if cached_total_results > 0
                    else []
                )
            else:
                # cached results are for a different search
                cached_page = []
                # trigger cache update
                metadata = []
        else:
            # no data in cache
            cached_page = []

        return cached_page, metadata
