docker stop $(docker ps -aqf "name=discovery_feed")
docker build -t creator_api .
docker run --rm -it --name discovery_feed -p 8080:5000 creator_api:latest