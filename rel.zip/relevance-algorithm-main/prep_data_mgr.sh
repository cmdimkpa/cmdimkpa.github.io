cd server/utils/data-manager
npm init -y && npm install --save mongodb args-parser lodash bson flat moment axios