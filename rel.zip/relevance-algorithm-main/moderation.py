from server.utils.base import (
    db_operation,
    _force_dict,
    pd,
    ModelParameters,
    send_to_slack,
)
from datetime import datetime
import time


def parse_iso_date_format(date_):
    year, month, day = date_.split("-")
    dt = datetime(int(year), int(month), int(day))
    return dt.isoformat()


def fetch_data(context, op_args, **kwargs):
    return db_operation(
        args=_force_dict(kwargs),
        context=context,
        op_args=op_args,
    )


def analyze_mixpanel(events):
    content_data = [
        {"content_id": event.get("properties").get("content_id")}
        for event in events
        if event.get("properties").get("content_id")
    ]

    content_data_df = pd.DataFrame(content_data)

    grouped_content_data = (
        content_data_df.groupby("content_id").size().reset_index(name="count")
    )

    max_count = grouped_content_data["count"].max()

    grouped_content_data["normalized_count"] = grouped_content_data["count"] / max_count

    content_ids_only = list(
        grouped_content_data[
            grouped_content_data["normalized_count"]
            > ModelParameters.MODERATION_TRENDING_CUTOFF.value
        ]["content_id"]
    )

    return content_ids_only


def retrieve_specific_fields(_type, data):
    emitted_time = datetime.utcnow().isoformat()

    if _type not in ["content", "comments", "trending"]:
        return "Wrong value provided"

    extracted_data = [
        {
            "type": _type,
            "_id": item.get("_id", ""),
            "createdAt": item.get("createdAt", ""),
            "emittedAt": emitted_time,
        }
        for item in data
    ]

    return extracted_data


def send_notification(notification):
    now = datetime.now()
    current_hour = now.hour
    current_minute = now.minute

    if current_hour % 2 == 0 and 0 <= current_minute <= 25:
        send_to_slack(notification)


def moderation_test(kwargs):

    start_time = time.time()

    reported_contents = (
        fetch_data("fetch_reported_contents", ["content"], **kwargs) or []
    )

    contents_from_time_period = (
        fetch_data(
            "fetch_contents_period",
            [
                "content",
                parse_iso_date_format(kwargs.get("from_date")),
                parse_iso_date_format(kwargs.get("to_date")),
            ],
            **kwargs,
        )
        or []
    )

    reported_comments = (
        fetch_data("fetch_reported_comments", ["comments"], **kwargs) or []
    )

    mixpanel_events = (
        fetch_data(
            "mixpanel_export",
            [
                kwargs.get("from_date"),
                kwargs.get("to_date"),
                ModelParameters.MIXPANEL_EVENT_LIST.value,
                ModelParameters.MIXPANEL_EVENT_LIMIT.value,
                ModelParameters.MIXPANEL_EVENT_FILTER.value,
            ],
            **kwargs,
        )
        or []
    )

    trending_contents = analyze_mixpanel(mixpanel_events)

    filtered_reported_contents = [
        content
        for content in contents_from_time_period
        if content
        and content.get("abstract")
        and content["abstract"].get("contentId") in trending_contents
        and int(content.get("reportCount", 0)) == 0
        and content.get("moderationStatus") == "uncheck"
    ]

    merged_results = sum(
        [
            retrieve_specific_fields("content", reported_contents),
            retrieve_specific_fields("comments", reported_comments),
            retrieve_specific_fields("trending", filtered_reported_contents),
        ],
        [],
    )

    merged_results = sorted(merged_results, key=lambda k: k["createdAt"], reverse=True)

    db_operation(
        args=_force_dict(kwargs),
        context="write_moderation_data",
        op_args=[merged_results],
    )

    end_time = time.time()

    elapsed = end_time - start_time

    notification = (
        f"Moderation Algo results successfully written to DB on {kwargs.get('env')}.\nRuntime --> "
        f"{elapsed:.2f} secs\nNumber of results --> {len(merged_results)}"
    )

    send_notification(notification)

    return merged_results
