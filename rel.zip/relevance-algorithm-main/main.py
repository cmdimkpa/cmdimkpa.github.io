from controllers import *
from flask import Flask, request
from flask_cors import CORS

app = Flask(__name__)

CORS(app)


def run_startup_hooks():
    commands = [
        "bash /app/entrypoint.sh",
    ]
    subprocess.Popen(" && ".join(commands), shell=True)


@app.route("/data-explorer", methods=["GET"])
def data_explorer():
    params = request.args
    item_class = params.get("item_class")
    experiment_date = params.get("experiment_date", get_today())
    return read_telemetry_artifact(
        contexts="*", item_class=item_class, experiment_date=experiment_date
    )


@app.route("/files/<string:file>", methods=["GET", "PUT", "DELETE"])
def file_handler(file):
    token = request.args.get("token")
    _file = f"static/{file}"
    if token == get_hash(file):
        if request.method.lower() == "get":
            try:
                return send_file(_file)
            except:
                # return empty byte sequence if file cannot be returned
                return b""
        if request.method.lower() == "put":
            payload = request.get_json(force=True, silent=True) or {}
            _data = payload.get("data")
            with open(_file, "w") as handle:
                handle.write(json.dumps(_data))
            return responsify(HTTPStatus.OK, "OK")
        if request.method.lower() == "delete":
            try:
                os.remove(_file)
                return responsify(HTTPStatus.OK, "OK")
            except:
                return responsify(HTTPStatus.NOT_FOUND, "NOT_FOUND")
    else:
        return responsify(HTTPStatus.FORBIDDEN, "FORBIDDEN")


@app.route("/<string:task>", methods=["POST", "GET"])
def task_handler(task):
    try:
        if task not in SUPPORTED_TASKS:
            return responsify(
                HTTPStatus.NOT_FOUND,
                f"A handler for task: {task.upper()} was not found",
            )
        elif task == "fetch-errors":
            return load_many_from_cache(item_class="log", load_limit=20)
        elif task == "fetch-logs":
            return load_many_from_cache(item_class="requests.log", load_limit=50)
        else:
            auth = request.headers.get("Authorization")
            if auth == fetch_correct_header():
                return handle_request(task=task, request=request)
            else:
                return responsify(HTTPStatus.UNAUTHORIZED, "Unauthorized")
    except Exception as error:
        log_error(error)
        print(str(error))
        return responsify(HTTPStatus.SERVICE_UNAVAILABLE, "Something went wrong")


if __name__ == "__main__":
    port = int(os.environ.get("FLASK_APPLICATION_PORT", 5000))
    run_startup_hooks()
    app.run(host="0.0.0.0", port=port)
