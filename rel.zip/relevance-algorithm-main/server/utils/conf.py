from http import HTTPStatus
import datetime
import os
import sys
import pathlib

_HERE_ = pathlib.Path().parent.resolve()
_UTILS_DIR_ = os.path.join(_HERE_, "server/utils/")
sys.path.append(_UTILS_DIR_)

from common import *

MAX_PIPE_OPERATION_RETRIES = 10
PIPE_OPERATION_RETRY_DELAY_SECONDS = 5

SYNCHRONOUS_PIPE_OPERATIONS = ["find", "find_one", "export"]

ENV_BASE_URLS = {
    "non-prod": "http://api.mia-%s.taringa.net/relevance-algorithm/",
    "prod": "http://api.app.taringa.net/relevance-algorithm/",
}

UTIL_TASKS = [
    "force-train-model",
    "pull-data",
    "local-train-model",
    "mark-unmark-ambassadors",
    "moderation-test",
    "v2-train",
]

SUPPORTED_TASKS = [
    "fetch-creators",
    "fetch-posts",
    "fetch-errors",
    "fetch-logs",
    *UTIL_TASKS,
]


BAD_STATUS = [
    HTTPStatus.SERVICE_UNAVAILABLE,
    HTTPStatus.FORBIDDEN,
    HTTPStatus.UNAUTHORIZED,
    HTTPStatus.BAD_REQUEST,
    HTTPStatus.NOT_FOUND,
]

PIPE_RUNNERS = {
    "mongodb": os.path.join(_HERE_, "server/utils/data-manager/pipe.js"),
    "pymongo": os.path.join(_HERE_, "server/utils/data-manager/pipe.py"),
    "mixpanel": os.path.join(_HERE_, "server/utils/data-manager/mixpanel-pipe.js"),
}

ARGS_SCHEMAS = {
    "mongodb": {
        "conn_string": str,
        "target_db": str,
        "target_collection": str,
        "mode": str,
        "query": dict,
        "projection": dict,
        "filter": dict,
        "patch": dict,
        "object_id_fields": list,
        "date_fields": list,
        "limit": int,
    },
    "mixpanel": {
        "secret_object": dict,
        "from_date": str,
        "to_date": str,
        "event_list": list,
        "event_limit": int,
        "event_filter": str,
        "mode": str,
    },
}

ARGS_SCHEMAS["pymongo"] = ARGS_SCHEMAS["mongodb"]

PIPE_TEMPLATES = {
    "mongodb": 'node %s --connection_string="%s" \
                            --database_name="%s" --collection_name="%s" --mode="%s" --query="%s" --projection="%s" \
                            --filter="%s" --patch="%s" --object_id_fields="%s" --date_fields="%s" --limit=%d',
    "pymongo": 'python3 %s --connection-string="%s" \
                            --database-name="%s" --collection-name="%s" --mode="%s" --query="%s" --projection="%s" \
                            --filter="%s" --patch="%s" --oids-filepath="%s" --date-filepath="%s" --limit=%d',
    "mixpanel": 'node %s --secret_object="%s" --from_date="%s" --to_date="%s" \
                         --event_list="%s" --event_limit="%s" --event_filter="%s" --mode="%s"',
}


def serialize_fields(item: dict) -> dict:

    available_object_id_fields = [field for field in OBJECT_ID_FIELDS if field in item]

    for field in available_object_id_fields:
        object_id = item[field]
        item[field] = str(object_id)

    for field in item:
        field_value = item[field]
        if isinstance(field_value, datetime.datetime):
            item[field] = field_value.isoformat()

    return item


def build_mongodb_args(*args):
    (
        context,
        db_type,
        conn_string,
        target_db,
        target_collection,
        mode,
        query,
        projection,
        filter,
        patch,
        object_id_fields,
        date_fields,
        limit,
    ) = args

    args_hash = get_hash(args)
    store_key = f"db_pipe_result_{args_hash}"

    if context == "write_mongo_vector":
        transformed = []
        for item in query:
            objects = item["item"]
            item["item"] = serialize_fields(objects)
            transformed.append(item)
        query = transformed

    query_str = write_json_file(query)
    projection_str = write_json_file(projection)
    filter_str = write_json_file(filter)
    patch_str = write_json_file(patch)
    object_id_fields_str = write_json_file(object_id_fields)
    date_fields_str = write_json_file(date_fields)

    query_params = (
        PIPE_RUNNERS[db_type],
        conn_string,
        target_db,
        target_collection,
        mode,
        query_str,
        projection_str,
        filter_str,
        patch_str,
        object_id_fields_str,
        date_fields_str,
        limit,
    )

    return query_params, mode, store_key


def build_mixpanel_args(*args):
    (
        context,
        db_type,
        secret_object,
        from_date,
        to_date,
        event_list,
        event_limit,
        event_filter,
        mode,
    ) = args

    args_hash = get_hash(args)
    store_key = f"db_pipe_result_{args_hash}"

    secret_object_str = write_json_file(secret_object)
    event_list_str = write_json_file(event_list)

    query_params = (
        PIPE_RUNNERS["mixpanel"],
        secret_object_str,
        from_date,
        to_date,
        event_list_str,
        event_limit,
        event_filter,
        mode,
    )

    return query_params, mode, store_key


ARGS_BUILDERS = {
    "mongodb": build_mongodb_args,
    "mixpanel": build_mixpanel_args,
}

ARGS_BUILDERS["pymongo"] = ARGS_BUILDERS["mongodb"]
