/*
    this pipe will run queries against Mixpanel API and send results
    back to the calling Python process
*/

const args = require('args-parser')(process.argv);
const fs = require('fs');
const _ = require('lodash');
const { MixpanelAPIWrapper: MixpanelClient } = require("./mixpanelWrapper");

// process variables
let {
    secret_object: secretObjectPath,
    from_date: fromDate,
    to_date: toDate,
    event_list: eventListPath,
    event_limit: eventLimit,
    event_filter: eventFilter,
    mode
} = args;

const dataFromPath = (path) => {
    let obj =  JSON.parse(fs.readFileSync(path));
    fs.unlinkSync(path);
    return obj;
}

let dataPaths = [
   secretObjectPath, eventListPath
];

// read data
let [secretObject, eventList] = dataPaths.map((path) => dataFromPath(path))

async function main() {

    // create and connect client
    const client = new MixpanelClient(secretObject);

    // execute query and communicate results
    let result;

    if (mode === "export") result = await client.exportEvents(fromDate, toDate, eventList, eventLimit, eventFilter);

    // pass result as message to Python process
    let message = JSON.stringify(result);
    console.log(message);
}

// run pipe process
main();