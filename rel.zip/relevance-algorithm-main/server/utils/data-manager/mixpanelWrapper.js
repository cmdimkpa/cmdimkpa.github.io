/*
* Wrapper utility for the Mixpanel API
* */

const axios = require('axios');

class MixpanelAPIWrapper {

   constructor(secretObject) {
       let {username, secret, projectId} = secretObject;
       this.username = username;
       this.secret = secret;
       this.projectId = projectId;
       this.exportUrl = `https://data.mixpanel.com/api/2.0/export?project_id=${this.projectId}`;
       this.options = {
           auth: {
               username: this.username,
               password: this.secret
           },
           accept: "text/plain"
       }
   }

   addQueryParam(paramKey, paramValue){
       this.exportUrl += `&${paramKey}=${paramValue}`;
   }

   async exportEvents(fromDate, toDate, eventList, eventLimit, eventFilter){

        // build query
        this.addQueryParam("from_date", fromDate);
        this.addQueryParam("to_date", toDate);
        this.addQueryParam("event", JSON.stringify(eventList));
        this.addQueryParam("limit", eventLimit);
        this.addQueryParam("where", eventFilter);

        // query Mixpanel and return results
        return await axios.get(this.exportUrl, this.options)
            .then((response) => response.data)
            .catch((err) => {
                console.log(err);
                return [];
            })
   }

}


module.exports = {
    MixpanelAPIWrapper
}