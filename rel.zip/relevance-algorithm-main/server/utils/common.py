# common functions accessed between utilities

from typing import List, Any, Tuple, Union, Callable
import os
import pathlib
import json
from random import random
from hashlib import sha256

_HERE_ = pathlib.Path().parent.resolve()

OBJECT_ID_FIELDS = [
    "_id",
    "accountId",
    "profileId",
    "userId",
    "authorId",
    "contentId",
]


def rand_num(size: int = 10) -> str:
    """generate a random [10] digit string"""
    return str(random()).split(".")[1][:size]


def write_json_file(_data):
    rand = rand_num(size=20)
    rand_file = os.path.join(_HERE_, f"{rand}.json")
    with open(rand_file, "w") as handle:
        handle.write(json.dumps(_data))
    return rand_file


def get_hash(obj: Any):
    obj = str(obj).encode()
    hasher = sha256()
    hasher.update(obj)
    return hasher.hexdigest()
