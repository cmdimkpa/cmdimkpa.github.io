WEBSERVER_BASE_URL = "http://CreatorAPI.taringa.repl.co"
WEBSERVER_TEST_SECRET_NAME = "Some test secret"
WEBSERVER_TEST_SECRET_VALUE = "Some test secret value"
TEST_TOKEN = "f50bde790c602643318c932c7ab236b9"


def apply_test_token(client):
    client.secrets_token = TEST_TOKEN
    return client


TEST_COUNTRY = "AR"
TEST_USERNAME = "internal"
TEST_PREFERENCES = ["videogames", "cryptocurrencies", "politics"]

MODEL_TRAINING_TEST_ARGS = dict(
    env="stage",
    no_likes=True,
    local_training_run=True,
    post_context=True,
    post_status="published",
    from_mongo=True,
    live_run=True,
    preferences=TEST_PREFERENCES,
)

TELEMETRY_TEST_DATA = dict(
    username=TEST_USERNAME, country=TEST_COUNTRY, preferences=TEST_PREFERENCES
)
